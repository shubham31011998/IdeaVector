// Generated with GitHub Copilot - [Tracking ID: Hexure-Copilot]
import { useEffect, useState } from 'react';
import { useNavigate } from 'react-router-dom';
import {
  Typography,
  Table,
  TableBody,
  TableCell,
  TableContainer,
  TableHead,
  TableRow,
  Paper,
  Chip,
  IconButton,
  Box,
  CircularProgress,
  Button,
  Dialog,
  DialogTitle,
  DialogContent,
  DialogContentText,
  DialogActions,
  Alert,
  Snackbar,
} from '@mui/material';
import VisibilityIcon from '@mui/icons-material/Visibility';
import DeleteIcon from '@mui/icons-material/Delete';
import AddIcon from '@mui/icons-material/Add';
import { getIdeas, deleteIdea } from '../api/api';

export default function MyIdeasPage() {
  const navigate = useNavigate();
  const [ideas, setIdeas] = useState([]);
  const [loading, setLoading] = useState(true);
  const [error, setError] = useState('');
  const [deleteDialogOpen, setDeleteDialogOpen] = useState(false);
  const [ideaToDelete, setIdeaToDelete] = useState(null);
  const [notification, setNotification] = useState({ open: false, message: '', severity: 'success' });

  const fetchIdeas = async () => {
    setLoading(true);
    setError('');
    try {
      const response = await getIdeas();
      if (response.success && response.ideas) {
        setIdeas(response.ideas);
      } else {
        setError(response.message || 'Failed to load ideas');
      }
    } catch (err) {
      console.error('Error fetching ideas:', err);
      setError(err.message || 'Failed to load ideas. Please try again.');
    } finally {
      setLoading(false);
    }
  };

  useEffect(() => {
    fetchIdeas();
  }, []);

  const handleDeleteClick = (idea) => {
    setIdeaToDelete(idea);
    setDeleteDialogOpen(true);
  };

  const handleDeleteConfirm = async () => {
    setDeleteDialogOpen(false);
    try {
      const response = await deleteIdea(ideaToDelete.ideaId);
      setIdeaToDelete(null);
      
      setNotification({
        open: true,
        message: response?.message || 'Idea deleted successfully!',
        severity: 'success'
      });
      
      fetchIdeas();
    } catch (err) {
      console.error('Error deleting idea:', err);
      setNotification({
        open: true,
        message: err.message || 'Failed to delete idea',
        severity: 'error'
      });
    }
  };

  const handleDeleteCancel = () => {
    setDeleteDialogOpen(false);
    setIdeaToDelete(null);
  };

  const handleCloseNotification = () => {
    setNotification({ ...notification, open: false });
    setIdeaToDelete(null);
  };

  if (loading) {
    return (
      <Box sx={{ display: 'flex', justifyContent: 'center', mt: 8 }}>
        <CircularProgress />
      </Box>
    );
  }

  return (
    <>
      <Box sx={{ display: 'flex', justifyContent: 'space-between', alignItems: 'center', mb: 3 }}>
        <Typography variant="h4" sx={{ fontWeight: 700 }}>All Ideas</Typography>
        <Button
          variant="contained"
          startIcon={<AddIcon />}
          onClick={() => navigate('/ideas/new')}
          sx={{
            borderRadius: '50px', px: 3,
            background: 'linear-gradient(135deg, #00E5FF, #7C4DFF)',
            '&:hover': { background: 'linear-gradient(135deg, #00B2CC, #5A1FCB)' },
          }}
        >
          New Idea
        </Button>
      </Box>

      {error && (
        <Alert severity="error" sx={{ mb: 2 }}>
          {error}
        </Alert>
      )}

      {ideas.length === 0 ? (
        <Typography color="text.secondary">
          You haven&apos;t submitted any ideas yet.
        </Typography>
      ) : (
        <TableContainer component={Paper}>
          <Table>
            <TableHead>
              <TableRow>
                <TableCell>Title</TableCell>
                <TableCell>Status</TableCell>
                <TableCell>Category</TableCell>
                <TableCell>Date</TableCell>
                <TableCell align="right">Actions</TableCell>
              </TableRow>
            </TableHead>
            <TableBody>
              {ideas.map((idea) => {
                const statusColors = {
                  'New': { bg: 'rgba(0,229,255,0.1)', color: '#00E5FF' },
                  'Old': { bg: 'rgba(255,171,64,0.1)', color: '#FFAB40' },
                  'Closed': { bg: 'rgba(255,82,82,0.1)', color: '#FF5252' },
                };
                const sc = statusColors[idea.status] || statusColors['New'];
                return (
                <TableRow key={idea.ideaId} hover sx={{ '&:hover': { bgcolor: 'rgba(0,229,255,0.03)' } }}>
                  <TableCell sx={{ fontWeight: 600 }}>{idea.title}</TableCell>
                  <TableCell>
                    <Chip
                      label={idea.status || 'New'}
                      size="small"
                      sx={{ bgcolor: sc.bg, color: sc.color, fontWeight: 700 }}
                    />
                  </TableCell>
                  <TableCell>
                    {idea.categoryId || 'N/A'}
                  </TableCell>
                  <TableCell>
                    {new Date(idea.createdDate).toLocaleDateString()}
                  </TableCell>
                  <TableCell align="right">
                    <IconButton
                      size="small"
                      color="primary"
                      onClick={() => navigate(`/ideas/${idea.publicGuId}`)}
                    >
                      <VisibilityIcon fontSize="small" />
                    </IconButton>
                    <IconButton
                      size="small"
                      color="error"
                      onClick={() => handleDeleteClick(idea)}
                    >
                      <DeleteIcon fontSize="small" />
                    </IconButton>
                  </TableCell>
                </TableRow>
                );
              })}
            </TableBody>
          </Table>
        </TableContainer>
      )}

      {/* Delete Confirmation Dialog */}
      <Dialog
        open={deleteDialogOpen}
        onClose={handleDeleteCancel}
        PaperProps={{
          sx: {
            borderRadius: 4,
            p: 1,
            background: 'linear-gradient(135deg, #1a1a2e 0%, #16213e 100%)',
            border: '1px solid rgba(255,82,82,0.3)',
          },
        }}
      >
        <DialogTitle sx={{ fontWeight: 700, color: '#FF5252' }}>
          🗑️ Delete Idea
        </DialogTitle>
        <DialogContent>
          <DialogContentText sx={{ color: 'text.secondary' }}>
            Are you sure you want to delete this idea? This action cannot be undone.
          </DialogContentText>
        </DialogContent>
        <DialogActions sx={{ px: 3, pb: 2 }}>
          <Button
            onClick={handleDeleteCancel}
            sx={{ borderRadius: '50px', px: 3 }}
          >
            Cancel
          </Button>
          <Button
            onClick={handleDeleteConfirm}
            variant="contained"
            color="error"
            sx={{
              borderRadius: '50px',
              px: 3,
              background: 'linear-gradient(135deg, #FF5252, #D32F2F)',
              '&:hover': { background: 'linear-gradient(135deg, #D32F2F, #B71C1C)' },
            }}
          >
            Yes, Delete
          </Button>
        </DialogActions>
      </Dialog>

      {/* Success/Error Snackbar */}
      <Snackbar
        open={notification.open}
        autoHideDuration={4000}
        onClose={handleCloseNotification}
        anchorOrigin={{ vertical: 'top', horizontal: 'center' }}
      >
        <Alert 
          onClose={handleCloseNotification} 
          severity={notification.severity} 
          sx={{ width: '100%', borderRadius: 3 }}
        >
          {notification.message}
        </Alert>
      </Snackbar>
    </>
  );
}
