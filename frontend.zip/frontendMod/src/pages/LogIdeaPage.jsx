// Generated with GitHub Copilot - [Tracking ID: Hexure-Copilot]
import { useState, useEffect } from 'react';
import { useNavigate } from 'react-router-dom';
import {
  Typography,
  TextField,
  Button,
  Box,
  MenuItem,
  Alert,
  Card,
  CardContent,
  CircularProgress,
  Snackbar,
  Chip,
} from '@mui/material';
import CreateIcon from '@mui/icons-material/Create';
import CheckCircleIcon from '@mui/icons-material/CheckCircle';
import WarningIcon from '@mui/icons-material/Warning';
import { createIdea, getCategories } from '../api/api';
import { useDuplicateCheck } from '../hooks/useDuplicateCheck';
import SimilarIdeasModal from '../components/SimilarIdeasModal';

export default function LogIdeaPage() {
  const navigate = useNavigate();
  const [form, setForm] = useState({
    title: '',
    description: '',
    categoryId: '',
    subCategoryId: '',
  });
  const [categories, setCategories] = useState([]);
  const [subcategories, setSubcategories] = useState([]);
  const [error, setError] = useState('');
  const [loading, setLoading] = useState(false);
  const [successMessage, setSuccessMessage] = useState('');
  const [showSuccess, setShowSuccess] = useState(false);
  const [loadingCategories, setLoadingCategories] = useState(true);
  const [showSimilarModal, setShowSimilarModal] = useState(false);
  const [proceedWithDuplicate, setProceedWithDuplicate] = useState(false);
  
  // Duplicate check hook
  const { checkDuplicate, isChecking, duplicateResult, clearResult } = useDuplicateCheck(800);

  // Fetch categories on component mount
  useEffect(() => {
    const fetchCategories = async () => {
      try {
        setLoadingCategories(true);
        const response = await getCategories();
        if (response.success && response.data) {
          setCategories(response.data);
        }
      } catch (err) {
        console.error('Failed to fetch categories:', err);
        setError('Failed to load categories. Please refresh the page.');
      } finally {
        setLoadingCategories(false);
      }
    };

    fetchCategories();
  }, []);

  // Check for duplicates when title or description changes
  useEffect(() => {
    if (form.title.trim() || form.description.trim()) {
      checkDuplicate(form.title, form.description);
    } else {
      clearResult();
    }
  }, [form.title, form.description, checkDuplicate, clearResult]);

  const handleChange = (e) => {
    const { name, value } = e.target;
    setForm((prev) => ({ ...prev, [name]: value }));

    // Update subcategories when category changes
    if (name === 'categoryId') {
      setForm((prev) => ({ ...prev, subCategoryId: '' }));
      const category = categories.find(cat => cat.categoryId === parseInt(value));
      if (category) {
        setSubcategories(category.subCategories || []);
      }
    }
  };

  const handleSubmit = async (e) => {
    e.preventDefault();
    setError('');
    
    if (!form.title.trim() || !form.description.trim() || !form.categoryId || !form.subCategoryId) {
      setError('All fields are required');
      return;
    }

    // Check for duplicates before submitting (unless user already chose to proceed)
    if (!proceedWithDuplicate && duplicateResult?.hasSimilar) {
      setShowSimilarModal(true);
      return;
    }

    setLoading(true);
    try {
      // Get current user from localStorage
      const userStr = localStorage.getItem('user');
      if (!userStr) {
        setError('Please login to create an idea');
        navigate('/login');
        return;
      }

      const user = JSON.parse(userStr);
      
      // Prepare idea data matching backend CreateIdeaDto (PascalCase)
      const ideaData = {
        Title: form.title,
        Description: form.description,
        CategoryId: parseInt(form.categoryId),
        SubCategoryId: parseInt(form.subCategoryId),
        CustomerShared: false,
        CreatedBy: user.userId || user.UserId
      };

      const response = await createIdea(ideaData);

      if (response.success) {
        setSuccessMessage('Idea submitted successfully!');
        setShowSuccess(true);
        // Navigate after 2 seconds
        setTimeout(() => {
          navigate('/ideas');
        }, 2000);
      }
    } catch (err) {
      setError(err.message || 'Failed to create idea. Please try again.');
    } finally {
      setLoading(false);
    }
  };

  const handleCloseSuccess = () => {
    setShowSuccess(false);
  };

  return (
    <>
      <Box sx={{ display: 'flex', alignItems: 'center', gap: 2, mb: 3 }}>
        <Box sx={{
          width: 48, height: 48, borderRadius: '14px',
          background: 'linear-gradient(135deg, #00E5FF, #7C4DFF)',
          display: 'flex', alignItems: 'center', justifyContent: 'center',
        }}>
          <CreateIcon sx={{ color: '#fff', fontSize: 24 }} />
        </Box>
        <Typography variant="h4">
          Log a New Idea
        </Typography>
      </Box>

      {error && (
        <Alert severity="error" sx={{ mb: 2, borderRadius: 3 }}>
          {error}
        </Alert>
      )}

      <Card sx={{ maxWidth: 600 }}>
        <CardContent sx={{ p: 3 }}>
          {loadingCategories ? (
            <Box sx={{ display: 'flex', justifyContent: 'center', py: 4 }}>
              <CircularProgress />
            </Box>
          ) : (
          <Box component="form" onSubmit={handleSubmit}>
        <TextField
          name="title"
          label="Title"
          fullWidth
          margin="normal"
          required
          value={form.title}
          onChange={handleChange}
        />
        <TextField
          name="description"
          label="Description"
          fullWidth
          margin="normal"
          required
          multiline
          minRows={4}
          value={form.description}
          onChange={handleChange}
        />
        
        {/* Duplicate Check Status */}
        {(form.title.trim() || form.description.trim()) && (
          <Alert
            severity={
              isChecking ? 'info' :
              duplicateResult?.hasSimilar ? 'warning' :
              duplicateResult ? 'success' : 'info'
            }
            icon={
              isChecking ? <CircularProgress size={20} /> :
              duplicateResult?.hasSimilar ? <WarningIcon /> :
              duplicateResult ? <CheckCircleIcon /> : null
            }
            sx={{ mt: 2, borderRadius: 2 }}
            action={
              duplicateResult?.hasSimilar ? (
                <Button
                  color="inherit"
                  size="small"
                  onClick={() => setShowSimilarModal(true)}
                >
                  View Similar ({duplicateResult.totalSimilar})
                </Button>
              ) : null
            }
          >
            {isChecking ? (
              <Typography variant="body2">Checking for similar ideas...</Typography>
            ) : duplicateResult?.hasSimilar ? (
              <Box>
                <Typography variant="body2" fontWeight="bold">Similar ideas found!</Typography>
                <Typography variant="body2">{duplicateResult.suggestion}</Typography>
              </Box>
            ) : duplicateResult && !duplicateResult.hasSimilar ? (
              <Typography variant="body2">{duplicateResult.suggestion}</Typography>
            ) : null}
          </Alert>
        )}
        <TextField
          name="categoryId"
          label="Category"
          fullWidth
          margin="normal"
          required
          select
          value={form.categoryId}
          onChange={handleChange}
        >
          {categories.length === 0 ? (
            <MenuItem value="" disabled>No categories available</MenuItem>
          ) : (
            categories.map((c) => (
              <MenuItem key={c.categoryId} value={c.categoryId}>
                {c.categoryName}
              </MenuItem>
            ))
          )}
        </TextField>
        
        {/* Subcategory - Only show when category is selected */}
        {form.categoryId && (
          <TextField
            name="subCategoryId"
            label="Sub Category"
            fullWidth
            margin="normal"
            required
            select
            value={form.subCategoryId}
            onChange={handleChange}
          >
            {subcategories.length === 0 ? (
              <MenuItem value="" disabled>No subcategories available</MenuItem>
            ) : (
              subcategories.map((c) => (
                <MenuItem key={c.categoryId} value={c.categoryId}>
                  {c.categoryName}
                </MenuItem>
              ))
            )}
          </TextField>
        )}

        <Box sx={{ mt: 2, display: 'flex', gap: 2 }}>
          <Button
            type="submit"
            variant="contained"
            disabled={loading}
            sx={{
              borderRadius: '50px', px: 4,
              background: 'linear-gradient(135deg, #00E5FF, #7C4DFF)',
              '&:hover': { background: 'linear-gradient(135deg, #00B2CC, #5A1FCB)' },
            }}
          >
            {loading ? 'Submitting…' : 'Submit Idea'}
          </Button>
          <Button variant="outlined" onClick={() => navigate(-1)} sx={{ borderRadius: '50px', px: 3 }}>
            Cancel
          </Button>
        </Box>
      </Box>
          )}
        </CardContent>
      </Card>

      {/* Success Snackbar */}
      <Snackbar
        open={showSuccess}
        autoHideDuration={2000}
        onClose={handleCloseSuccess}
        anchorOrigin={{ vertical: 'top', horizontal: 'center' }}
      >
        <Alert onClose={handleCloseSuccess} severity="success" sx={{ width: '100%', borderRadius: 3 }}>
          {successMessage}
        </Alert>
      </Snackbar>

      {/* Similar Ideas Modal */}
      <SimilarIdeasModal
        open={showSimilarModal}
        duplicateResult={duplicateResult}
        onClose={() => setShowSimilarModal(false)}
        onProceed={() => {
          setProceedWithDuplicate(true);
          setShowSimilarModal(false);
          // Trigger form submission
          setTimeout(() => {
            const form = document.querySelector('form');
            if (form) {
              form.requestSubmit();
            }
          }, 100);
        }}
      />
    </>
  );
}
