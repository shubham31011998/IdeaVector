// Generated with GitHub Copilot - [Tracking ID: Hexure-Copilot]
import { useState, useEffect } from 'react';
import { useNavigate, Link } from 'react-router-dom';
import {
  Box,
  Card,
  CardContent,
  TextField,
  Button,
  Typography,
  Alert,
} from '@mui/material';
import LightbulbIcon from '@mui/icons-material/Lightbulb';
import { useAuth } from '../context/AuthContext';

export default function LoginPage() {
  const { login } = useAuth();
  const navigate = useNavigate();
  const [username, setUsername] = useState('');
  const [password, setPassword] = useState('');
  const [error, setError] = useState('');
  const [loading, setLoading] = useState(false);

  // Check if user is already logged in
  useEffect(() => {
    const user = localStorage.getItem('user');
    if (user) {
      navigate('/', { replace: true });
    }
  }, [navigate]);

  const handleSubmit = async (e) => {
    e.preventDefault();
    setError('');
    setLoading(true);
    try {
      await login(username, password);
      navigate('/');
    } catch (err) {
      setError(err.message);
    } finally {
      setLoading(false);
    }
  };

  return (
    <Box
      sx={{
        minHeight: '100vh',
        display: 'flex',
        alignItems: 'center',
        justifyContent: 'center',
        background: 'linear-gradient(135deg, #0B0F1A 0%, #131827 40%, #1A1040 100%)',
        position: 'relative',
        overflow: 'hidden',
      }}
    >
      {/* Decorative blurred circles */}
      <Box sx={{
        position: 'absolute', width: 300, height: 300, borderRadius: '50%',
        background: 'rgba(0,229,255,0.05)', top: -80, left: -80, filter: 'blur(40px)',
      }} />
      <Box sx={{
        position: 'absolute', width: 200, height: 200, borderRadius: '50%',
        background: 'rgba(124,77,255,0.15)', bottom: -50, right: -50, filter: 'blur(40px)',
      }} />

      <Card sx={{
        width: 420, p: 3, borderRadius: 5,
        backdropFilter: 'blur(20px)',
        bgcolor: 'rgba(19,24,39,0.95)',
        border: '1px solid rgba(0,229,255,0.12)',
        boxShadow: '0 20px 60px rgba(0,0,0,0.5)',
      }}>
        <CardContent>
          <Box sx={{ textAlign: 'center', mb: 3 }}>
            <Box sx={{
              width: 64, height: 64, borderRadius: '18px', mx: 'auto', mb: 2,
              background: 'linear-gradient(135deg, #00E5FF, #7C4DFF)',
              display: 'flex', alignItems: 'center', justifyContent: 'center',
            }}>
              <LightbulbIcon sx={{ fontSize: 36, color: '#fff' }} />
            </Box>
            <Typography
              variant="h4"
              sx={{
                fontWeight: 800,
                letterSpacing: '-0.03em',
                background: 'linear-gradient(135deg, #00E5FF, #7C4DFF)',
                backgroundClip: 'text',
                WebkitBackgroundClip: 'text',
                WebkitTextFillColor: 'transparent',
              }}
            >
              NextGen Ideas
            </Typography>
            <Typography variant="body2" color="text.secondary" sx={{ mt: 0.5 }}>
              Sign in to continue
            </Typography>
          </Box>

          {error && (
            <Alert severity="error" sx={{ mb: 2 }}>
              {error}
            </Alert>
          )}

          <Box component="form" onSubmit={handleSubmit}>
            <TextField
              label="Username"
              fullWidth
              margin="normal"
              required
              autoFocus
              value={username}
              onChange={(e) => setUsername(e.target.value)}
            />
            <TextField
              label="Password"
              type="password"
              fullWidth
              margin="normal"
              required
              value={password}
              onChange={(e) => setPassword(e.target.value)}
            />
            <Button
              type="submit"
              variant="contained"
              fullWidth
              size="large"
              disabled={loading}
              sx={{
                mt: 2, py: 1.4,
                background: 'linear-gradient(135deg, #00E5FF, #7C4DFF)',
                fontSize: '1rem', fontWeight: 600,
                '&:hover': {
                  background: 'linear-gradient(135deg, #00B2CC, #5A1FCB)',
                },
              }}
            >
              {loading ? 'Signing in…' : 'Sign In'}
            </Button>
          </Box>

          <Box sx={{ mt: 3, textAlign: 'center' }}>
            <Typography variant="body2" color="text.secondary">
              Don't have an account?{' '}
              <Link
                to="/register"
                style={{
                  color: '#00E5FF',
                  textDecoration: 'none',
                  fontWeight: 600,
                }}
              >
                Sign Up
              </Link>
            </Typography>
          </Box>
        </CardContent>
      </Card>
    </Box>
  );
}
