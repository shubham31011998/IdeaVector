import { useEffect, useState } from 'react';
import {
  Typography,
  Box,
  Avatar,
  Card,
  CardContent,
  Grid,
  Chip,
  TextField,
  Button,
  CircularProgress,
  Divider,
  Alert,
} from '@mui/material';
import StarIcon from '@mui/icons-material/Star';
import LightbulbIcon from '@mui/icons-material/Lightbulb';
import CalendarMonthIcon from '@mui/icons-material/CalendarMonth';
import EditIcon from '@mui/icons-material/Edit';
import SaveIcon from '@mui/icons-material/Save';
import CloseIcon from '@mui/icons-material/Close';
import { useAuth } from '../context/AuthContext';
import { getMyIdeas, getProfile, updateProfile } from '../api/mockApi';

export default function ProfilePage() {
  const { user } = useAuth();
  const [profile, setProfile] = useState(null);
  const [ideas, setIdeas] = useState([]);
  const [loading, setLoading] = useState(true);
  const [editing, setEditing] = useState(false);
  const [bio, setBio] = useState('');
  const [saveMsg, setSaveMsg] = useState('');

  useEffect(() => {
    Promise.all([getProfile(), getMyIdeas()]).then(([prof, ideaList]) => {
      setProfile(prof);
      setBio(prof.bio || '');
      setIdeas(ideaList);
      setLoading(false);
    });
  }, []);

  const handleSave = async () => {
    const updated = await updateProfile({ bio });
    setProfile(updated);
    setEditing(false);
    setSaveMsg('Profile updated!');
    setTimeout(() => setSaveMsg(''), 2500);
  };

  if (loading) {
    return (
      <Box sx={{ display: 'flex', justifyContent: 'center', mt: 8 }}>
        <CircularProgress />
      </Box>
    );
  }

  const statusBreakdown = ideas.reduce((acc, idea) => {
    acc[idea.status] = (acc[idea.status] || 0) + 1;
    return acc;
  }, {});

  const statusColors = {
    'New': { bg: 'rgba(0,229,255,0.12)', color: '#00E5FF' },
    'Old': { bg: 'rgba(255,171,64,0.15)', color: '#FFAB40' },
    'Closed': { bg: 'rgba(255,82,82,0.12)', color: '#FF5252' },
  };

  return (
    <>
      {/* Profile header card */}
      <Card sx={{ mb: 3, overflow: 'visible' }}>
        <Box
          sx={{
            height: 120,
            background: 'linear-gradient(135deg, #0D1321 0%, #1A237E 50%, #0D1321 100%)',
            borderRadius: '18px 18px 0 0',
            position: 'relative',
          }}
        />
        <CardContent sx={{ pt: 0, px: 4, pb: 3, position: 'relative' }}>
          <Avatar
            sx={{
              width: 90,
              height: 90,
              fontSize: '2.2rem',
              fontWeight: 800,
              background: 'linear-gradient(135deg, #00E5FF, #7C4DFF)',
              border: '4px solid #fff',
              boxShadow: '0 4px 20px rgba(0,0,0,0.15)',
              position: 'relative',
              top: -45,
              mb: -4,
            }}
          >
            {user?.username?.charAt(0).toUpperCase()}
          </Avatar>

          <Box sx={{ display: 'flex', justifyContent: 'space-between', alignItems: 'flex-start' }}>
            <Box>
              <Typography variant="h4" sx={{ fontWeight: 700 }}>
                {user?.username}
              </Typography>
              <Box sx={{ display: 'flex', alignItems: 'center', gap: 1, mt: 0.5 }}>
                <CalendarMonthIcon sx={{ fontSize: 16, color: 'text.secondary' }} />
                <Typography variant="body2" color="text.secondary">
                  Member since {profile?.joinedAt ? new Date(profile.joinedAt).toLocaleDateString('en-US', { month: 'long', year: 'numeric' }) : 'April 2026'}
                </Typography>
              </Box>
            </Box>
            {!editing && (
              <Button
                variant="outlined"
                size="small"
                startIcon={<EditIcon />}
                onClick={() => setEditing(true)}
                sx={{ borderRadius: '50px', mt: 1 }}
              >
                Edit Bio
              </Button>
            )}
          </Box>

          {saveMsg && (
            <Alert severity="success" sx={{ mt: 2, borderRadius: 3 }}>
              {saveMsg}
            </Alert>
          )}

          {editing ? (
            <Box sx={{ mt: 2 }}>
              <TextField
                multiline
                minRows={2}
                maxRows={4}
                fullWidth
                placeholder="Write something about yourself..."
                value={bio}
                onChange={(e) => setBio(e.target.value)}
              />
              <Box sx={{ display: 'flex', gap: 1, mt: 1.5 }}>
                <Button
                  variant="contained"
                  size="small"
                  startIcon={<SaveIcon />}
                  onClick={handleSave}
                  sx={{ borderRadius: '50px', px: 3 }}
                >
                  Save
                </Button>
                <Button
                  variant="outlined"
                  size="small"
                  startIcon={<CloseIcon />}
                  onClick={() => { setEditing(false); setBio(profile.bio || ''); }}
                  sx={{ borderRadius: '50px' }}
                >
                  Cancel
                </Button>
              </Box>
            </Box>
          ) : (
            <Typography variant="body1" color="text.secondary" sx={{ mt: 2, fontStyle: profile?.bio ? 'normal' : 'italic' }}>
              {profile?.bio || 'No bio yet — click Edit Bio to add one.'}
            </Typography>
          )}
        </CardContent>
      </Card>

      {/* Stats row */}
      <Grid container spacing={3} sx={{ mb: 3 }}>
        <Grid size={{ xs: 12, sm: 4 }}>
          <Card sx={{
            background: 'linear-gradient(135deg, #0D1321, #1A237E)',
            color: '#fff',
          }}>
            <CardContent sx={{ textAlign: 'center', py: 3 }}>
              <LightbulbIcon sx={{ fontSize: 32, color: '#00E5FF', mb: 1 }} />
              <Typography variant="h3" sx={{ fontWeight: 800 }}>
                {ideas.length}
              </Typography>
              <Typography variant="body2" sx={{ opacity: 0.7 }}>
                Ideas Submitted
              </Typography>
            </CardContent>
          </Card>
        </Grid>
        <Grid size={{ xs: 12, sm: 4 }}>
          <Card sx={{
            background: 'linear-gradient(135deg, #0D1321, #1A237E)',
            color: '#fff',
          }}>
            <CardContent sx={{ textAlign: 'center', py: 3 }}>
              <StarIcon sx={{ fontSize: 32, color: '#FFD93D', mb: 1 }} />
              <Typography variant="h3" sx={{ fontWeight: 800 }}>
                {ideas.filter(i => i.customerShared).length}
              </Typography>
              <Typography variant="body2" sx={{ opacity: 0.7 }}>
                Shared with Customer
              </Typography>
            </CardContent>
          </Card>
        </Grid>
        <Grid size={{ xs: 12, sm: 4 }}>
          <Card sx={{
            background: 'linear-gradient(135deg, #0D1321, #1A237E)',
            color: '#fff',
          }}>
            <CardContent sx={{ textAlign: 'center', py: 3 }}>
              <StarIcon sx={{ fontSize: 32, color: '#69F0AE', mb: 1 }} />
              <Typography variant="h3" sx={{ fontWeight: 800 }}>
                {ideas.filter(i => i.status === 'New').length}
              </Typography>
              <Typography variant="body2" sx={{ opacity: 0.7 }}>
                New Ideas
              </Typography>
            </CardContent>
          </Card>
        </Grid>
      </Grid>

      {/* Status breakdown */}
      {Object.keys(statusBreakdown).length > 0 && (
        <Card sx={{ mb: 3 }}>
          <CardContent>
            <Typography variant="h6" sx={{ fontWeight: 700, mb: 2 }}>
              Ideas by Status
            </Typography>
            <Box sx={{ display: 'flex', flexWrap: 'wrap', gap: 1.5 }}>
              {Object.entries(statusBreakdown).map(([status, count]) => {
                const sc = statusColors[status] || statusColors['New'];
                return (
                  <Chip
                    key={status}
                    label={`${status}: ${count}`}
                    sx={{
                      bgcolor: sc.bg,
                      color: sc.color,
                      fontWeight: 700,
                      fontSize: '0.85rem',
                      px: 1,
                    }}
                  />
                );
              })}
            </Box>
          </CardContent>
        </Card>
      )}

      {/* Recent contributions */}
      <Card>
        <CardContent>
          <Typography variant="h6" sx={{ fontWeight: 700, mb: 2 }}>
            Recent Contributions
          </Typography>
          {ideas.length === 0 ? (
            <Typography variant="body2" color="text.secondary" sx={{ fontStyle: 'italic' }}>
              No ideas submitted yet.
            </Typography>
          ) : (
            ideas.slice(0, 5).map((idea, idx) => {
              const sc = statusColors[idea.status] || statusColors['New'];
              return (
                <Box key={idea.ideaId}>
                  {idx > 0 && <Divider sx={{ my: 1.5 }} />}
                  <Box sx={{ display: 'flex', justifyContent: 'space-between', alignItems: 'center' }}>
                    <Box>
                      <Typography variant="subtitle1" sx={{ fontWeight: 600 }}>
                        {idea.title}
                      </Typography>
                      <Box sx={{ display: 'flex', alignItems: 'center', gap: 1, mt: 0.5 }}>
                        <Chip
                          label={idea.status}
                          size="small"
                          sx={{ bgcolor: sc.bg, color: sc.color, fontWeight: 600 }}
                        />
                        <Typography variant="caption" color="text.secondary">
                          {new Date(idea.createdDate).toLocaleDateString()}
                        </Typography>
                      </Box>
                    </Box>
                    <Chip
                      label={idea.customerShared ? 'Shared' : 'Internal'}
                      size="small"
                      sx={{ fontWeight: 600 }}
                    />
                  </Box>
                </Box>
              );
            })
          )}
        </CardContent>
      </Card>
    </>
  );
}
