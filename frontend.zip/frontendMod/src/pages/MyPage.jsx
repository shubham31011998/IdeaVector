import { useEffect, useState, useRef, useCallback } from 'react';
import { useNavigate } from 'react-router-dom';
import {
  Typography,
  Grid,
  Card,
  CardContent,
  CardActions,
  Button,
  Box,
  CircularProgress,
  Chip,
  IconButton,
} from '@mui/material';
import AddCircleOutlineIcon from '@mui/icons-material/AddCircle';
import ListAltIcon from '@mui/icons-material/ListAlt';
import ChevronLeftIcon from '@mui/icons-material/ChevronLeft';
import ChevronRightIcon from '@mui/icons-material/ChevronRight';
import {
  PieChart, Pie, Cell, Tooltip as ReTooltip, Legend, ResponsiveContainer,
} from 'recharts';
import { useAuth } from '../context/AuthContext';
import { getMyIdeas } from '../api/mockApi';

const CHART_COLORS = ['#00E5FF', '#7C4DFF', '#FFD93D', '#FF6584', '#48BB78', '#F6AD55'];

export default function MyPage() {
  const { user } = useAuth();
  const navigate = useNavigate();
  const [stats, setStats] = useState(null);
  const [categoryData, setCategoryData] = useState([]);

  const [featuredIdeas, setFeaturedIdeas] = useState([]);
  const [activeSlide, setActiveSlide] = useState(0);
  const timerRef = useRef(null);

  const startAutoSlide = useCallback(() => {
    if (timerRef.current) clearInterval(timerRef.current);
    timerRef.current = setInterval(() => {
      setActiveSlide((prev) => prev);
      setFeaturedIdeas((ideas) => {
        if (ideas.length > 0) {
          setActiveSlide((prev) => (prev + 1) % ideas.length);
        }
        return ideas;
      });
    }, 4000);
  }, []);

  useEffect(() => {
    if (featuredIdeas.length > 1) startAutoSlide();
    return () => { if (timerRef.current) clearInterval(timerRef.current); };
  }, [featuredIdeas, startAutoSlide]);

  const goToSlide = (idx) => {
    setActiveSlide(idx);
    startAutoSlide();
  };

  const goPrev = () => {
    setActiveSlide((prev) => (prev - 1 + featuredIdeas.length) % featuredIdeas.length);
    startAutoSlide();
  };

  const goNext = () => {
    setActiveSlide((prev) => (prev + 1) % featuredIdeas.length);
    startAutoSlide();
  };

  useEffect(() => {
    getMyIdeas().then((ideas) => {
      setStats({ total: ideas.length, sharedCount: ideas.filter(i => i.customerShared).length });

      // Status breakdown for pie chart
      const statusMap = {};
      ideas.forEach((i) => {
        statusMap[i.status] = (statusMap[i.status] || 0) + 1;
      });
      setCategoryData(Object.entries(statusMap).map(([name, value]) => ({ name, value })));

      // Featured ideas: most recent ideas
      const sorted = [...ideas].sort((a, b) => new Date(b.createdDate) - new Date(a.createdDate));
      setFeaturedIdeas(sorted.slice(0, 5));
    });
  }, []);

  if (!stats) {
    return (
      <Box sx={{ display: 'flex', justifyContent: 'center', mt: 8 }}>
        <CircularProgress />
      </Box>
    );
  }

  return (
    <>
      <Box
        sx={{
          mb: 4,
          animation: 'fadeSlideIn 0.8s ease-out',
          '@keyframes fadeSlideIn': {
            '0%': { opacity: 0, transform: 'translateY(-20px)' },
            '100%': { opacity: 1, transform: 'translateY(0)' },
          },
        }}
      >
        <Typography
          variant="h4"
          sx={{
            fontWeight: 800,
            background: 'linear-gradient(135deg, #00E5FF, #7C4DFF)',
            WebkitBackgroundClip: 'text',
            WebkitTextFillColor: 'transparent',
            mb: 0.5,
          }}
        >
          Hey {user?.username}, ready to innovate? 🚀
        </Typography>
        <Typography variant="body1" sx={{ color: 'text.secondary', fontWeight: 500 }}>
          Your innovation hub — track, create, and bring ideas to life.
        </Typography>
      </Box>

      {/* Featured Ideas Carousel */}
      {featuredIdeas.length > 0 && (() => {
        const idea = featuredIdeas[activeSlide];
        const statusColors = {
          'New': { bg: '#E0F7FF', color: '#00B2CC' },
          'Old': { bg: '#FFF3E0', color: '#F6AD55' },
          'Closed': { bg: '#FFEBEE', color: '#FF5252' },
        };
        const sc = statusColors[idea.status] || statusColors['New'];
        return (
          <Box sx={{ mb: 4 }}>
            <Typography variant="subtitle1" sx={{ fontWeight: 700, mb: 1.5, color: 'text.primary' }}>
              &#11088; Recent Ideas
            </Typography>
            <Box sx={{ position: 'relative', height: 200 }}>

              {/* Left arrow */}
              {featuredIdeas.length > 1 && (
                <IconButton
                  size="small"
                  onClick={goPrev}
                  sx={{
                    position: 'absolute', left: -20, top: '50%', transform: 'translateY(-50%)',
                    zIndex: 2,
                    width: 36, height: 36,
                    background: 'linear-gradient(135deg, #00E5FF, #7C4DFF)',
                    color: '#fff',
                    boxShadow: '0 3px 12px rgba(0,229,255,0.35)',
                    '&:hover': { background: 'linear-gradient(135deg, #00B2CC, #5A1FCB)' },
                  }}
                >
                  <ChevronLeftIcon />
                </IconButton>
              )}

              {/* Single slide card */}
              <Card
                onClick={() => navigate(`/ideas/${idea.ideaId}`)}
                sx={{
                  height: 200,
                  cursor: 'pointer',
                  border: '1px solid rgba(0,229,255,0.2)',
                  background: 'linear-gradient(135deg, #0D1321 0%, #1A237E 50%, #0D1321 100%)',
                  transition: 'all 0.5s cubic-bezier(0.4, 0, 0.2, 1)',
                  position: 'relative',
                  overflow: 'hidden',
                  '&:hover': {
                    boxShadow: '0 12px 40px rgba(0,229,255,0.25)',
                    borderColor: 'rgba(0,229,255,0.5)',
                    transform: 'scale(1.01)',
                  },
                  '&::before': {
                    content: '""',
                    position: 'absolute',
                    top: 0,
                    left: 0,
                    right: 0,
                    height: '4px',
                    background: 'linear-gradient(90deg, #00E5FF, #7C4DFF, #FF6584)',
                  },
                }}
              >
                <CardContent sx={{ display: 'flex', alignItems: 'center', gap: 3, py: 3, px: 4, boxSizing: 'border-box', overflow: 'hidden' }}>
                  {/* Status badge */}
                  <Box sx={{
                    width: 72, height: 72, flexShrink: 0, borderRadius: '16px',
                    background: `linear-gradient(135deg, ${sc.color}22, ${sc.color}44)`,
                    border: `1px solid ${sc.color}66`,
                    display: 'flex', flexDirection: 'column', alignItems: 'center', justifyContent: 'center',
                    gap: 0.5,
                  }}>
                    <Typography sx={{ fontSize: '1.2rem', lineHeight: 1 }}>💡</Typography>
                    <Typography sx={{ color: sc.color, fontWeight: 800, fontSize: '0.65rem', textTransform: 'uppercase', letterSpacing: 1 }}>
                      {idea.status}
                    </Typography>
                  </Box>

                  {/* Content */}
                  <Box sx={{ flex: 1, display: 'flex', flexDirection: 'column', justifyContent: 'center' }}>
                    <Typography variant="h5" sx={{ fontWeight: 800, mb: 0.5, color: '#fff', letterSpacing: '-0.02em' }}>
                      {idea.title}
                    </Typography>
                    <Typography variant="body2" sx={{
                      mb: 1.5, color: 'rgba(255,255,255,0.6)',
                      overflow: 'hidden', textOverflow: 'ellipsis',
                      display: '-webkit-box', WebkitLineClamp: 2, WebkitBoxOrient: 'vertical',
                    }}>
                      {idea.description}
                    </Typography>
                    <Box sx={{ display: 'flex', alignItems: 'center', gap: 1 }}>
                      <Box sx={{ width: 6, height: 6, borderRadius: '50%', bgcolor: '#00E5FF' }} />
                      <Typography variant="caption" sx={{ color: 'rgba(255,255,255,0.45)', fontStyle: 'italic' }}>
                        Idea Logged on : {new Date(idea.createdDate).toLocaleDateString('en-GB', { day: 'numeric', month: 'long', year: 'numeric' })}
                      </Typography>
                    </Box>
                  </Box>

                  {/* CTA */}
                  <Box sx={{ display: 'flex', alignItems: 'center' }}>
                    <Button
                      variant="contained"
                      size="small"
                      sx={{
                        borderRadius: '50px', px: 3, py: 1,
                        background: 'linear-gradient(135deg, #00E5FF, #7C4DFF)',
                        boxShadow: '0 4px 15px rgba(0,229,255,0.3)',
                        fontWeight: 700,
                        textTransform: 'none',
                        '&:hover': {
                          background: 'linear-gradient(135deg, #00B2CC, #5A1FCB)',
                          boxShadow: '0 6px 20px rgba(0,229,255,0.45)',
                        },
                      }}
                      onClick={(e) => { e.stopPropagation(); navigate(`/ideas/${idea.ideaId}`); }}
                    >
                      View Details →
                    </Button>
                  </Box>
                </CardContent>
              </Card>

              {/* Right arrow */}
              {featuredIdeas.length > 1 && (
                <IconButton
                  size="small"
                  onClick={goNext}
                  sx={{
                    position: 'absolute', right: -20, top: '50%', transform: 'translateY(-50%)',
                    zIndex: 2,
                    width: 36, height: 36,
                    background: 'linear-gradient(135deg, #00E5FF, #7C4DFF)',
                    color: '#fff',
                    boxShadow: '0 3px 12px rgba(0,229,255,0.35)',
                    '&:hover': { background: 'linear-gradient(135deg, #00B2CC, #5A1FCB)' },
                  }}
                >
                  <ChevronRightIcon />
                </IconButton>
              )}
            </Box>

            {/* Dots */}
            {featuredIdeas.length > 1 && (
              <Box sx={{ display: 'flex', justifyContent: 'center', gap: 1, mt: 2 }}>
                {featuredIdeas.map((_, idx) => (
                  <Box
                    key={idx}
                    onClick={() => goToSlide(idx)}
                    sx={{
                      width: idx === activeSlide ? 28 : 10,
                      height: 10,
                      borderRadius: 5,
                      cursor: 'pointer',
                      transition: 'all 0.3s ease',
                      background: idx === activeSlide
                        ? 'linear-gradient(135deg, #00E5FF, #7C4DFF)'
                        : '#B0BEC5',
                      boxShadow: idx === activeSlide ? '0 2px 8px rgba(0,229,255,0.4)' : 'none',
                      '&:hover': {
                        background: idx === activeSlide
                          ? 'linear-gradient(135deg, #00E5FF, #7C4DFF)'
                          : '#78909C',
                      },
                    }}
                  />
                ))}
              </Box>
            )}
          </Box>
        );
      })()}

      <Grid container spacing={3}>
        {/* Quick actions */}
        <Grid size={{ xs: 12, sm: 6 }}>
          <Card sx={{ height: '100%' }}>
            <CardContent>
              <Box sx={{
                width: 52, height: 52, borderRadius: '14px', mb: 2,
                background: 'linear-gradient(135deg, #00E5FF, #00B2CC)',
                display: 'flex', alignItems: 'center', justifyContent: 'center',
              }}>
                <AddCircleOutlineIcon sx={{ color: '#fff', fontSize: 28 }} />
              </Box>
              <Typography variant="h6" sx={{ mt: 1 }}>
                Log a New Idea
              </Typography>
              <Typography variant="body2" color="text.secondary">
                Got something on your mind? Share it with the team.
              </Typography>
            </CardContent>
            <CardActions sx={{ px: 2, pb: 2 }}>
              <Button
                variant="contained"
                size="small"
                onClick={() => navigate('/ideas/new')}
                sx={{ borderRadius: '50px', px: 3 }}
              >
                Go &rarr;
              </Button>
            </CardActions>
          </Card>
        </Grid>
        <Grid size={{ xs: 12, sm: 6 }}>
          <Card sx={{ height: '100%' }}>
            <CardContent>
              <Box sx={{
                width: 52, height: 52, borderRadius: '14px', mb: 2,
                background: 'linear-gradient(135deg, #7C4DFF, #B47CFF)',
                display: 'flex', alignItems: 'center', justifyContent: 'center',
              }}>
                <ListAltIcon sx={{ color: '#fff', fontSize: 28 }} />
              </Box>
              <Typography variant="h6" sx={{ mt: 1 }}>
                View All Ideas
              </Typography>
              <Typography variant="body2" color="text.secondary">
                Review, rate, or delete your submitted ideas.
              </Typography>
            </CardContent>
            <CardActions sx={{ px: 2, pb: 2 }}>
              <Button
                variant="contained"
                color="secondary"
                size="small"
                onClick={() => navigate('/ideas')}
                sx={{ borderRadius: '50px', px: 3 }}
              >
                Go &rarr;
              </Button>
            </CardActions>
          </Card>
        </Grid>

        {/* Category Breakdown (left, tall) + Stats meters (right, stacked) */}
        <Grid size={{ xs: 12, sm: 6 }}>
          <Card sx={{ height: '100%' }}>
            <CardContent>
              <Typography variant="h6" sx={{ fontWeight: 700, mb: 2 }}>
                Ideas by Status
              </Typography>
              {categoryData.length > 0 ? (
                <ResponsiveContainer width="100%" height={320}>
                  <PieChart>
                    <Pie
                      data={categoryData}
                      cx="50%"
                      cy="50%"
                      innerRadius={65}
                      outerRadius={110}
                      paddingAngle={4}
                      dataKey="value"
                      stroke="none"
                    >
                      {categoryData.map((_, idx) => (
                        <Cell key={idx} fill={CHART_COLORS[idx % CHART_COLORS.length]} />
                      ))}
                    </Pie>
                    <ReTooltip
                      contentStyle={{
                        borderRadius: 12,
                        border: 'none',
                        boxShadow: '0 4px 20px rgba(0,0,0,0.12)',
                      }}
                    />
                    <Legend />
                  </PieChart>
                </ResponsiveContainer>
              ) : (
                <Typography variant="body2" color="text.secondary">
                  No ideas yet to chart.
                </Typography>
              )}
            </CardContent>
          </Card>
        </Grid>

        {/* Right column: two stat cards stacked */}
        <Grid size={{ xs: 12, sm: 6 }}>
          <Box sx={{ display: 'flex', flexDirection: 'column', gap: 3, height: '100%' }}>
            <Card sx={{ flex: 1, '&:hover': { transform: 'translateY(-4px)' } }}>
              <CardContent sx={{ textAlign: 'center', py: 3, position: 'relative' }}>
                <Typography sx={{ fontWeight: 600, mb: 1, color: 'text.secondary' }}>Total Ideas</Typography>
                <ResponsiveContainer width="100%" height={120}>
                  <PieChart>
                    <Pie
                      data={[
                        { value: stats.total },
                        { value: Math.max(50 - stats.total, 0) },
                      ]}
                      cx="50%" cy="100%"
                      startAngle={180} endAngle={0}
                      innerRadius={60} outerRadius={85}
                      paddingAngle={0}
                      dataKey="value"
                      stroke="none"
                    >
                      <Cell fill="url(#semiGrad1)" />
                      <Cell fill="#E8EAF0" />
                    </Pie>
                    <defs>
                      <linearGradient id="semiGrad1" x1="0" y1="0" x2="1" y2="0">
                        <stop offset="0%" stopColor="#00E5FF" />
                        <stop offset="100%" stopColor="#00B2CC" />
                      </linearGradient>
                    </defs>
                  </PieChart>
                </ResponsiveContainer>
                <Typography variant="h4" sx={{ fontWeight: 800, mt: -4 }}>{stats.total}</Typography>
              </CardContent>
            </Card>

            <Card sx={{ flex: 1, '&:hover': { transform: 'translateY(-4px)' } }}>
              <CardContent sx={{ textAlign: 'center', py: 3, position: 'relative' }}>
                <Typography sx={{ fontWeight: 600, mb: 1, color: 'text.secondary' }}>Shared with Customer</Typography>
                <ResponsiveContainer width="100%" height={120}>
                  <PieChart>
                    <Pie
                      data={[
                        { value: stats.sharedCount },
                        { value: Math.max(stats.total - stats.sharedCount, 0) },
                      ]}
                      cx="50%" cy="100%"
                      startAngle={180} endAngle={0}
                      innerRadius={60} outerRadius={85}
                      paddingAngle={0}
                      dataKey="value"
                      stroke="none"
                    >
                      <Cell fill="url(#semiGrad2)" />
                      <Cell fill="#E8EAF0" />
                    </Pie>
                    <defs>
                      <linearGradient id="semiGrad2" x1="0" y1="0" x2="1" y2="0">
                        <stop offset="0%" stopColor="#7C4DFF" />
                        <stop offset="100%" stopColor="#B47CFF" />
                      </linearGradient>
                    </defs>
                  </PieChart>
                </ResponsiveContainer>
                <Typography variant="h4" sx={{ fontWeight: 800, mt: -4 }}>
                  {stats.sharedCount}
                </Typography>
              </CardContent>
            </Card>
          </Box>
        </Grid>
      </Grid>
    </>
  );
}
