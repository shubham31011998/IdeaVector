// Generated with GitHub Copilot - [Tracking ID: Hexure-Copilot]
import { useEffect, useState } from 'react';
import { useParams, useNavigate } from 'react-router-dom';
import {
  Typography,
  Card,
  CardContent,
  Chip,
  Box,
  Button,
  Divider,
  CircularProgress,
  Dialog,
  DialogTitle,
  DialogContent,
  DialogContentText,
  DialogActions,
  Alert,
  Snackbar,
} from '@mui/material';
import ArrowBackIcon from '@mui/icons-material/ArrowBack';
import DeleteIcon from '@mui/icons-material/Delete';
import { getIdeaByGuid, deleteIdea } from '../api/api';

export default function IdeaDetailsPage() {
  const { id } = useParams();
  const navigate = useNavigate();
  const [idea, setIdea] = useState(null);
  const [loading, setLoading] = useState(true);
  const [error, setError] = useState('');
  const [deleteDialogOpen, setDeleteDialogOpen] = useState(false);
  const [notification, setNotification] = useState({ open: false, message: '', severity: 'success' });

  useEffect(() => {
    const fetchIdea = async () => {
      setLoading(true);
      setError('');
      try {
        const response = await getIdeaByGuid(id);
        if (response.success && response.data) {
          setIdea(response.data);
        } else {
          setError(response.message || 'Failed to load idea');
          setTimeout(() => navigate('/ideas'), 2000);
        }
      } catch (err) {
        console.error('Error fetching idea:', err);
        setError(err.message || 'Failed to load idea');
        setTimeout(() => navigate('/ideas'), 2000);
      } finally {
        setLoading(false);
      }
    };

    fetchIdea();
  }, [id, navigate]);

  const handleDeleteClick = () => {
    setDeleteDialogOpen(true);
  };

  const handleDeleteConfirm = async () => {
    setDeleteDialogOpen(false);
    try {
      const response = await deleteIdea(idea.ideaId);
      
      if (response && response.success) {
        setNotification({
          open: true,
          message: response.message || 'Idea deleted successfully!',
          severity: 'success'
        });
        // Navigate after 2 seconds
        setTimeout(() => {
          navigate('/ideas');
        }, 2000);
      }
    } catch (err) {
      console.error('Error deleting idea:', err);
      setNotification({
        open: true,
        message: err.message || 'Failed to delete idea',
        severity: 'error'
      });
    }
  };

  const handleDeleteCancel = () => {
    setDeleteDialogOpen(false);
  };

  const handleCloseNotification = () => {
    setNotification({ ...notification, open: false });
    setDeleteDialogOpen(false);
  };

  if (loading) {
    return (
      <Box sx={{ display: 'flex', justifyContent: 'center', mt: 8 }}>
        <CircularProgress />
      </Box>
    );
  }

  if (error) {
    return (
      <Alert severity="error" sx={{ mb: 2 }}>
        {error}
      </Alert>
    );
  }

  if (!idea) return null;

  return (
    <>
      <Button
        startIcon={<ArrowBackIcon />}
        onClick={() => navigate('/ideas')}
        sx={{ mb: 2, borderRadius: '50px' }}
      >
        Back to All Ideas
      </Button>

      <Card sx={{ borderRadius: 2, overflow: 'visible' }}>
        <Box sx={{
          height: 30, borderRadius: '28px 28px 0 0',
          background: 'linear-gradient(135deg, #00E5FF 0%, #7C4DFF 100%)',
        }} />
        <CardContent sx={{ p: 4 }}>
          <Box
            sx={{
              display: 'flex',
              justifyContent: 'space-between',
              alignItems: 'flex-start',
            }}
          >
            <Box>
              <Typography variant="h4" sx={{ fontWeight: 700 }}>{idea.title}</Typography>
              <Chip
                label={idea.status || 'New'}
                sx={{
                  mt: 1.5,
                  bgcolor: 'rgba(0,229,255,0.1)',
                  color: '#00E5FF',
                  fontWeight: 700,
                }}
              />
            </Box>
            <Button
              variant="outlined"
              color="error"
              startIcon={<DeleteIcon />}
              onClick={handleDeleteClick}
              sx={{ borderRadius: '50px' }}
            >
              Delete
            </Button>
          </Box>

          <Typography variant="body1" sx={{ color: 'rgba(255,255,255,0.45)',mt: 3, whiteSpace: 'pre-wrap' }}>
            {idea.description || 'No description provided'}
          </Typography>


          <Divider sx={{ my: 3 }} />
          <Typography variant="caption" sx={{ color: 'rgba(255,255,255,0.3)', mt: 2, display: 'block' }}>
            Submitted on {new Date(idea.createdDate).toLocaleString()}
          </Typography>

          {/* Info section */}
          {/* <Box sx={{ display: 'flex', gap: 2, flexWrap: 'wrap' }}>
            <Chip
              label={`Category ID: ${idea.categoryId}`}
              sx={{ fontWeight: 600 }}
            />
            <Chip
              label={`SubCategory ID: ${idea.subCategoryId}`}
              sx={{ fontWeight: 600 }}
            />
          </Box> */}
        </CardContent>
      </Card>

      {/* Delete Confirmation Dialog */}
      <Dialog
        open={deleteDialogOpen}
        onClose={handleDeleteCancel}
        PaperProps={{
          sx: {
            borderRadius: 4,
            p: 1,
            background: 'linear-gradient(135deg, #1a1a2e 0%, #16213e 100%)',
            border: '1px solid rgba(255,82,82,0.3)',
          },
        }}
      >
        <DialogTitle sx={{ fontWeight: 700, color: '#FF5252' }}>
          🗑️ Delete Idea
        </DialogTitle>
        <DialogContent>
          <DialogContentText sx={{ color: 'text.secondary' }}>
            Are you sure you want to delete this idea? This action cannot be undone.
          </DialogContentText>
        </DialogContent>
        <DialogActions sx={{ px: 3, pb: 2 }}>
          <Button
            onClick={handleDeleteCancel}
            sx={{ borderRadius: '50px', px: 3 }}
          >
            Cancel
          </Button>
          <Button
            onClick={handleDeleteConfirm}
            variant="contained"
            color="error"
            sx={{
              borderRadius: '50px',
              px: 3,
              background: 'linear-gradient(135deg, #FF5252, #D32F2F)',
              '&:hover': { background: 'linear-gradient(135deg, #D32F2F, #B71C1C)' },
            }}
          >
            Yes, Delete
          </Button>
        </DialogActions>
      </Dialog>

      {/* Success/Error Snackbar */}
      <Snackbar
        open={notification.open}
        autoHideDuration={notification.severity === 'success' ? 2000 : 6000}
        onClose={handleCloseNotification}
        anchorOrigin={{ vertical: 'top', horizontal: 'center' }}
      >
        <Alert 
          onClose={handleCloseNotification} 
          severity={notification.severity} 
          sx={{ width: '100%', borderRadius: 3 }}
        >
          {notification.message}
        </Alert>
      </Snackbar>
    </>
  );
}
