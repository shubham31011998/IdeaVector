import { createTheme, alpha } from '@mui/material/styles';

const theme = createTheme({
  palette: {
    mode: 'dark',
    primary: {
      main: '#00E5FF',
      light: '#6EFFFF',
      dark: '#00B2CC',
    },
    secondary: {
      main: '#7C4DFF',
      light: '#B47CFF',
      dark: '#5A1FCB',
    },
    background: {
      default: '#0B0F1A',
      paper: '#131827',
    },
    text: {
      primary: '#E8ECF4',
      secondary: '#8892A8',
    },
    success: {
      main: '#00E676',
    },
    warning: {
      main: '#FFAB40',
    },
    info: {
      main: '#40C4FF',
    },
    error: {
      main: '#FF5252',
    },
    divider: 'rgba(0,229,255,0.08)',
  },
  typography: {
    fontFamily: "'Inter', 'Segoe UI', 'Roboto', sans-serif",
    h3: { fontWeight: 700 },
    h4: { fontWeight: 700 },
    h5: { fontWeight: 600 },
    h6: { fontWeight: 600 },
    button: { textTransform: 'none', fontWeight: 600 },
  },
  shape: {
    borderRadius: 14,
  },
  components: {
    MuiCard: {
      styleOverrides: {
        root: {
          borderRadius: 18,
          background: '#131827',
          border: '1px solid rgba(0,229,255,0.08)',
          boxShadow: '0 4px 24px rgba(0,0,0,0.3)',
          transition: 'transform 0.2s ease, box-shadow 0.2s ease, border-color 0.2s ease',
          '&:hover': {
            transform: 'translateY(-3px)',
            boxShadow: '0 8px 32px rgba(0,229,255,0.12)',
            borderColor: 'rgba(0,229,255,0.2)',
          },
        },
      },
    },
    MuiButton: {
      styleOverrides: {
        root: {
          borderRadius: 12,
          padding: '8px 22px',
          fontSize: '0.9rem',
        },
        contained: {
          boxShadow: '0 4px 14px rgba(0,229,255,0.25)',
          '&:hover': {
            boxShadow: '0 6px 20px rgba(0,229,255,0.35)',
          },
        },
      },
    },
    MuiTextField: {
      styleOverrides: {
        root: {
          '& .MuiOutlinedInput-root': {
            borderRadius: 12,
          },
        },
      },
    },
    MuiChip: {
      styleOverrides: {
        root: {
          fontWeight: 600,
          borderRadius: 10,
        },
      },
    },
    MuiTableContainer: {
      styleOverrides: {
        root: {
          borderRadius: 18,
          background: '#131827',
          border: '1px solid rgba(0,229,255,0.08)',
          boxShadow: '0 4px 24px rgba(0,0,0,0.3)',
        },
      },
    },
    MuiTableHead: {
      styleOverrides: {
        root: {
          '& .MuiTableCell-head': {
            backgroundColor: 'rgba(0,229,255,0.06)',
            fontWeight: 700,
            color: '#00E5FF',
            fontSize: '0.85rem',
            letterSpacing: '0.03em',
          },
        },
      },
    },
    MuiTableRow: {
      styleOverrides: {
        root: {
          '&:last-child td': { borderBottom: 0 },
        },
      },
    },
  },
});

export default theme;
