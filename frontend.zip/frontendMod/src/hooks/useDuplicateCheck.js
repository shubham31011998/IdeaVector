// Generated with GitHub Copilot - [Tracking ID: Hexure-Copilot]
import { useState, useEffect, useCallback, useRef } from 'react';
import axios from 'axios';

const API_BASE_URL = 'http://localhost:5049';

/**
 * Custom hook for checking duplicate ideas with debouncing
 * @param {number} delay - Debounce delay in milliseconds (default: 800ms)
 * @returns {Object} - { checkDuplicate, isChecking, duplicateResult, clearResult }
 */
export const useDuplicateCheck = (delay = 800) => {
  const [isChecking, setIsChecking] = useState(false);
  const [duplicateResult, setDuplicateResult] = useState(null);
  const debounceTimerRef = useRef(null);
  const abortControllerRef = useRef(null);

  /**
   * Check for duplicate ideas via API
   * @param {string} title - Idea title
   * @param {string} description - Idea description
   */
  const checkDuplicate = useCallback((title, description) => {
    // Clear previous timer
    if (debounceTimerRef.current) {
      clearTimeout(debounceTimerRef.current);
    }

    // Cancel previous request if still pending
    if (abortControllerRef.current) {
      abortControllerRef.current.abort();
    }

    // Skip if both title and description are empty
    if (!title?.trim() && !description?.trim()) {
      setDuplicateResult(null);
      setIsChecking(false);
      return;
    }

    // Show loading state immediately
    setIsChecking(true);

    // Debounce the API call
    debounceTimerRef.current = setTimeout(async () => {
      try {
        // Create new abort controller for this request
        abortControllerRef.current = new AbortController();

        const response = await axios.post(
          `${API_BASE_URL}/api/search/check-duplicate`,
          {
            title: title || '',
            description: description || ''
          },
          {
            signal: abortControllerRef.current.signal
          }
        );

        setDuplicateResult(response.data);
        setIsChecking(false);
      } catch (error) {
        if (error.name === 'CanceledError' || axios.isCancel(error)) {
          // Request was cancelled, ignore
          console.log('Duplicate check cancelled');
        } else {
          console.error('Error checking duplicates:', error);
          setDuplicateResult(null);
          setIsChecking(false);
        }
      }
    }, delay);
  }, [delay]);

  /**
   * Clear the duplicate check result
   */
  const clearResult = useCallback(() => {
    setDuplicateResult(null);
    setIsChecking(false);
    
    if (debounceTimerRef.current) {
      clearTimeout(debounceTimerRef.current);
    }
    
    if (abortControllerRef.current) {
      abortControllerRef.current.abort();
    }
  }, []);

  // Cleanup on unmount
  useEffect(() => {
    return () => {
      if (debounceTimerRef.current) {
        clearTimeout(debounceTimerRef.current);
      }
      if (abortControllerRef.current) {
        abortControllerRef.current.abort();
      }
    };
  }, []);

  return {
    checkDuplicate,
    isChecking,
    duplicateResult,
    clearResult
  };
};
