// Generated with GitHub Copilot - [Tracking ID: Hexure-Copilot]
import axios from "axios";

const API_BASE_URL = "http://localhost:5049";

const api = axios.create({
  baseURL: API_BASE_URL
});

// Get all categories with subcategories
export const getCategories = async () => {
  try {
    const response = await api.get("/api/categories/nested");
    
    // Backend returns array directly without wrapper
    if (Array.isArray(response.data)) {
      return {
        success: true,
        data: response.data
      };
    } else if (response.data.success) {
      // Fallback if backend returns wrapped response
      return response.data;
    } else {
      throw new Error(response.data.message || "Failed to fetch categories");
    }
  } catch (error) {
    console.error("Error fetching categories:", error);
    if (error.response?.data) {
      const apiError = new Error(error.response.data.message || "Failed to fetch categories");
      throw apiError;
    }
    throw error;
  }
};

// Create a new idea
export const createIdea = async (ideaData) => {
  try {
    const response = await api.post("/api/ideas", ideaData);
    
    // Backend returns ApiResponse<IdeaDto> with Success, Message, Data, Errors
    if (response.data.success) {
      return response.data; // Returns { success: true, message: "...", data: IdeaDto }
    } else {
      const error = new Error(response.data.message || "Failed to create idea");
      error.errors = response.data.errors;
      throw error;
    }
  } catch (error) {
    console.error("Error creating idea:", error);
    // If axios error, extract the API response data
    if (error.response?.data) {
      const apiError = new Error(error.response.data.message || "Failed to create idea");
      apiError.errors = error.response.data.errors;
      throw apiError;
    }
    throw error;
  }
};

// Register a new user
export const registerUser = async (userData) => {
  try {
    const response = await api.post("/api/auth/register", userData);
    
    if (response.data.success) {
      return response.data; // Returns { success: true, message: "...", user: UserDto }
    } else {
      const error = new Error(response.data.message || "Failed to register");
      throw error;
    }
  } catch (error) {
    console.error("Error registering user:", error);
    if (error.response?.data) {
      const apiError = new Error(error.response.data.message || "Failed to register");
      throw apiError;
    }
    throw error;
  }
};

// Login user
export const loginUser = async (credentials) => {
  try {
    const response = await api.post("/api/auth/login", {
      UsernameOrEmail: credentials.UsernameOrEmail || credentials.username,
      Password: credentials.Password || credentials.password,
    });

    if (response.data.success) {
      return response.data; // Returns { success: true, user: UserDto }
    } else {
      const error = new Error(response.data.message || "Login failed");
      throw error;
    }
  } catch (error) {
    console.error("Error logging in:", error);
    if (error.response?.data) {
      const apiError = new Error(error.response.data.message || "Login failed");
      throw apiError;
    }
    throw error;
  }
};

// Get all ideas
export const getIdeas = async () => {
  try {
    const response = await api.get("/api/ideas");
    
    if (response.data.success) {
      return response.data; // Returns { success: true, ideas: IdeaDto[] }
    } else {
      throw new Error(response.data.message || "Failed to fetch ideas");
    }
  } catch (error) {
    console.error("Error fetching ideas:", error);
    if (error.response?.data) {
      const apiError = new Error(error.response.data.message || "Failed to fetch ideas");
      throw apiError;
    }
    throw error;
  }
};

// Get idea by public GUID
export const getIdeaByGuid = async (guid) => {
  try {
    const response = await api.get(`/api/ideas/public/${guid}`);
    
    if (response.data.success) {
      return response.data; // Returns { success: true, data: IdeaDto }
    } else {
      throw new Error(response.data.message || "Failed to fetch idea");
    }
  } catch (error) {
    console.error("Error fetching idea:", error);
    if (error.response?.data) {
      const apiError = new Error(error.response.data.message || "Failed to fetch idea");
      throw apiError;
    }
    throw error;
  }
};

// Delete idea by ID
export const deleteIdea = async (ideaId) => {
  try {
    const response = await api.delete(`/api/ideas/${ideaId}`);
    
    if (response.data.success) {
      return response.data; // Returns { success: true, message: "..." }
    } else {
      const error = new Error(response.data.message || "Failed to delete idea");
      error.errors = response.data.errors;
      throw error;
    }
  } catch (error) {
    console.error("Error deleting idea:", error);
    if (error.response?.data) {
      const apiError = new Error(error.response.data.message || "Failed to delete idea");
      apiError.errors = error.response.data.errors;
      throw apiError;
    }
    throw error;
  }
};

export default api;
