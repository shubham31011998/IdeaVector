// ---------------------------------------------------------------------------
// Mock API layer – mirrors the real endpoints so swapping in real calls later
// is a one-file change.  All functions return Promises to match fetch / axios.
// ---------------------------------------------------------------------------

const FAKE_DELAY = 400; // ms

// In-memory stores
let ideas = [
  {
    id: '1',
    title: 'Dark-mode toggle for the portal',
    description: 'Allow users to switch between light and dark themes for better accessibility.',
    category: 'UI/UX',
    createdBy: 'demo',
    createdAt: '2026-04-20T10:30:00Z',
    ratings: [4, 5, 3],
  },
  {
    id: '2',
    title: 'Weekly idea digest email',
    description: 'Send a weekly summary of the top-rated ideas to all employees.',
    category: 'Communication',
    createdBy: 'demo',
    createdAt: '2026-04-18T08:15:00Z',
    ratings: [5, 5],
  },
  {
    id: '3',
    title: 'Automated CI/CD pipeline for microservices',
    description: 'Set up GitHub Actions workflows to build, test, and deploy each microservice independently on merge to main.',
    category: 'DevOps',
    createdBy: 'demo',
    createdAt: '2026-04-17T14:00:00Z',
    ratings: [5, 4, 5],
  },
  {
    id: '4',
    title: 'Keyboard shortcut cheat-sheet overlay',
    description: 'Press "?" anywhere in the app to show a modal listing all available keyboard shortcuts.',
    category: 'UI/UX',
    createdBy: 'demo',
    createdAt: '2026-04-16T09:45:00Z',
    ratings: [3, 4],
  },
  {
    id: '5',
    title: 'GraphQL gateway for backend services',
    description: 'Introduce a single GraphQL gateway so the frontend can fetch data from multiple services in one round-trip.',
    category: 'Backend',
    createdBy: 'demo',
    createdAt: '2026-04-15T11:20:00Z',
    ratings: [5, 5, 4, 4],
  },
  {
    id: '6',
    title: 'Slack integration for new ideas',
    description: 'Post a notification to the #ideas Slack channel whenever someone submits a new idea.',
    category: 'Communication',
    createdBy: 'demo',
    createdAt: '2026-04-14T16:30:00Z',
    ratings: [4, 3, 5],
  },
  {
    id: '7',
    title: 'Drag-and-drop Kanban board for idea status',
    description: 'Visualise idea lifecycle (Draft → Review → Approved → Done) on a draggable Kanban board.',
    category: 'UI/UX',
    createdBy: 'demo',
    createdAt: '2026-04-13T08:00:00Z',
    ratings: [5, 5, 5],
  },
  {
    id: '8',
    title: 'Rate-limiting middleware',
    description: 'Add configurable rate-limiting to API endpoints to prevent abuse and ensure fair usage.',
    category: 'Backend',
    createdBy: 'demo',
    createdAt: '2026-04-12T13:15:00Z',
    ratings: [4, 4],
  },
  {
    id: '9',
    title: 'Infrastructure-as-Code with Terraform',
    description: 'Migrate cloud resources to Terraform modules so environments can be spun up or torn down reproducibly.',
    category: 'DevOps',
    createdBy: 'demo',
    createdAt: '2026-04-11T10:00:00Z',
    ratings: [5, 4, 3],
  },
  {
    id: '10',
    title: 'Monthly all-hands idea showcase',
    description: 'Dedicate 15 minutes of the monthly all-hands to demo the top 3 ideas from the portal.',
    category: 'Communication',
    createdBy: 'demo',
    createdAt: '2026-04-10T15:45:00Z',
    ratings: [4, 5, 5, 4],
  },
  {
    id: '11',
    title: 'Responsive mobile layout',
    description: 'Optimise all pages for mobile screens so employees can submit ideas on the go.',
    category: 'UI/UX',
    createdBy: 'demo',
    createdAt: '2026-04-09T07:30:00Z',
    ratings: [3, 4, 4],
  },
  {
    id: '12',
    title: 'Centralised logging with ELK stack',
    description: 'Ship application logs to Elasticsearch and set up Kibana dashboards for real-time monitoring.',
    category: 'DevOps',
    createdBy: 'demo',
    createdAt: '2026-04-08T12:00:00Z',
    ratings: [5, 5],
  },
  {
    id: '13',
    title: 'Caching layer with Redis',
    description: 'Add a Redis cache in front of frequently-read endpoints to cut response times by 60%.',
    category: 'Backend',
    createdBy: 'demo',
    createdAt: '2026-04-07T09:20:00Z',
    ratings: [4, 5, 5],
  },
  {
    id: '14',
    title: 'Onboarding wizard for new hires',
    description: 'A step-by-step walkthrough that introduces new employees to the Idea Portal on first login.',
    category: 'UI/UX',
    createdBy: 'demo',
    createdAt: '2026-04-06T14:10:00Z',
    ratings: [5, 4],
  },
  {
    id: '15',
    title: 'Anonymous idea submission mode',
    description: 'Let users submit ideas anonymously so people feel safe sharing bold or controversial thoughts.',
    category: 'Other',
    createdBy: 'demo',
    createdAt: '2026-04-05T11:50:00Z',
    ratings: [5, 5, 4, 5],
  },
  {
    id: '16',
    title: 'AI-powered duplicate detection',
    description: 'Use NLP to flag potentially duplicate ideas before submission so effort stays focused.',
    category: 'Backend',
    createdBy: 'demo',
    createdAt: '2026-04-04T08:30:00Z',
    ratings: [5, 5, 5],
  },
  {
    id: '17',
    title: 'Team-level idea dashboards',
    description: 'Allow managers to view and filter ideas scoped to their team for easier prioritisation.',
    category: 'Communication',
    createdBy: 'demo',
    createdAt: '2026-04-03T16:00:00Z',
    ratings: [4, 3, 4],
  },
  {
    id: '18',
    title: 'Blue-green deployments',
    description: 'Implement blue-green deployment strategy to achieve zero-downtime releases.',
    category: 'DevOps',
    createdBy: 'demo',
    createdAt: '2026-04-02T10:45:00Z',
    ratings: [5, 4, 4, 5],
  },
];

let nextId = 19;

const delay = (data) =>
  new Promise((resolve) => setTimeout(() => resolve(data), FAKE_DELAY));

// ---- AUTH -----------------------------------------------------------------

/** POST /api/auth/login */
export async function login({ username, password }) {
  const res = await fetch('https://localhost:7255/api/auth/login', {
    method: 'POST',
    headers: { 'Content-Type': 'application/json' },
    body: JSON.stringify({ userName: username, password }),
  });
  if (!res.ok) throw new Error('Invalid username or password');
  return res.json();
}

// ---- IDEAS ----------------------------------------------------------------

/** POST /api/ideas */
export async function logIdea(ideaData) {
  const res = await fetch('https://localhost:7255/api/ideas', {
    method: 'POST',
    headers: { 'Content-Type': 'application/json' },
    body: JSON.stringify(ideaData),
  });
  if (!res.ok) throw new Error('Failed to create idea');
  return res.json();
}

/** GET /api/ideas/my */
export async function getMyIdeas() {
  const res = await fetch('https://localhost:7255/api/ideas/my');
  if (!res.ok) throw new Error('Failed to fetch ideas');
  return res.json();
}

/** GET /api/ideas/:id */
export async function getIdeaById(id) {
  const res = await fetch(`https://localhost:7255/api/ideas/${id}`);
  if (!res.ok) throw new Error('Idea not found');
  return res.json();
}

/** DELETE /api/ideas/:id */
export async function deleteIdea(id) {
  const res = await fetch(`https://localhost:7255/api/ideas/${id}`, { method: 'DELETE' });
  if (!res.ok) throw new Error('Failed to delete idea');
  const text = await res.text();
  return text ? JSON.parse(text) : { success: true };
}

/** POST /api/ideas/:id/rate */
export async function rateIdea(id, { userId, score }) {
  const res = await fetch(`https://localhost:7255/api/ideas/${id}/rate`, {
    method: 'POST',
    headers: { 'Content-Type': 'application/json' },
    body: JSON.stringify({ userId, score }),
  });
  if (!res.ok) throw new Error('Failed to rate idea');
  return res.json();
}

// ---- PROFILE --------------------------------------------------------------

let profile = {
  bio: '',
  joinedAt: '2026-04-01T00:00:00Z',
};

/** GET /api/profile */
export async function getProfile() {
  return delay({ ...profile });
}

/** PUT /api/profile */
export async function updateProfile({ bio }) {
  profile = { ...profile, bio };
  return delay({ ...profile });
}
