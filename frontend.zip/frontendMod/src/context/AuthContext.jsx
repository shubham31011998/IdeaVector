// Generated with GitHub Copilot - [Tracking ID: Hexure-Copilot]
import { createContext, useContext, useState, useCallback } from 'react';
import { loginUser } from '../api/api';

const AuthContext = createContext(null);

export function AuthProvider({ children }) {
  const [user, setUser] = useState(() => {
    const stored = localStorage.getItem('user');
    return stored ? JSON.parse(stored) : null;
  });

  const loginAction = useCallback(async (username, password) => {
    const response = await loginUser({ username, password });
    
    if (response.success && response.user) {
      const u = {
        userId: response.user.UserId || response.user.userId,
        username: response.user.Username || response.user.username,
        email: response.user.Email || response.user.email
      };
      setUser(u);
      localStorage.setItem('user', JSON.stringify(u));
      return u;
    } else {
      throw new Error(response.message || 'Login failed');
    }
  }, []);

  const logout = useCallback(() => {
    setUser(null);
    localStorage.removeItem('user');
  }, []);

  return (
    <AuthContext.Provider value={{ user, login: loginAction, logout }}>
      {children}
    </AuthContext.Provider>
  );
}

export function useAuth() {
  const ctx = useContext(AuthContext);
  if (!ctx) throw new Error('useAuth must be used inside AuthProvider');
  return ctx;
}
