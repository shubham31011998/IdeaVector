// Generated with GitHub Copilot - [Tracking ID: Hexure-Copilot]
import { BrowserRouter, Routes, Route, Navigate } from 'react-router-dom';
import { CssBaseline } from '@mui/material';
import { ThemeProvider } from '@mui/material/styles';
import theme from './theme';
import { AuthProvider } from './context/AuthContext';
import ProtectedRoute from './components/ProtectedRoute';
import Layout from './components/Layout';
import LoginPage from './pages/LoginPage';
import RegisterPage from './pages/RegisterPage';
import DashboardPage from './pages/DashboardPage';
import MyPage from './pages/MyPage';
import LogIdeaPage from './pages/LogIdeaPage';
import MyIdeasPage from './pages/MyIdeasPage';
import IdeaDetailsPage from './pages/IdeaDetailsPage';
import ProfilePage from './pages/ProfilePage';

function App() {
  return (
    <ThemeProvider theme={theme}>
    <BrowserRouter>
      <CssBaseline />
      <AuthProvider>
        <Routes>
          <Route path="/login" element={<LoginPage />} />
          <Route path="/register" element={<RegisterPage />} />
          <Route
            element={
              <ProtectedRoute>
                <Layout />
              </ProtectedRoute>
            }
          >
            <Route path="/" element={<DashboardPage />} />
            <Route path="/dashboard" element={<DashboardPage />} />
            <Route path="/my" element={<MyPage />} />
            <Route path="/ideas/new" element={<LogIdeaPage />} />
            <Route path="/log-idea" element={<LogIdeaPage />} />
            <Route path="/ideas" element={<MyIdeasPage />} />
            <Route path="/ideas/:id" element={<IdeaDetailsPage />} />
            <Route path="/profile" element={<ProfilePage />} />
          </Route>
          <Route path="*" element={<Navigate to="/" replace />} />
        </Routes>
      </AuthProvider>
    </BrowserRouter>
    </ThemeProvider>
  );
}

export default App;
