// Generated with GitHub Copilot - [Tracking ID: Hexure-Copilot]
import { Navigate } from 'react-router-dom';
import { useAuth } from '../context/AuthContext';

export default function ProtectedRoute({ children }) {
  const { user } = useAuth();
  
  // Check both context and localStorage for user
  const hasUser = user || localStorage.getItem('user');
  
  if (!hasUser) return <Navigate to="/login" replace />;
  return children;
}
