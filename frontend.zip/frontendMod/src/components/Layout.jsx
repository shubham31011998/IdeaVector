import { useState } from 'react';
import { Outlet, useNavigate, useLocation } from 'react-router-dom';
import {
  AppBar,
  Toolbar,
  Typography,
  Button,
  Box,
  Container,
  Avatar,
  Chip,
  Drawer,
  List,
  ListItem,
  ListItemButton,
  ListItemIcon,
  ListItemText,
  IconButton,
  Tooltip,
} from '@mui/material';
import LogoutIcon from '@mui/icons-material/Logout';
import AutoAwesomeIcon from '@mui/icons-material/AutoAwesome';
import HomeRoundedIcon from '@mui/icons-material/HomeRounded';
import AddCircleRoundedIcon from '@mui/icons-material/AddCircleRounded';
import ListAltRoundedIcon from '@mui/icons-material/ListAltRounded';
import PersonRoundedIcon from '@mui/icons-material/PersonRounded';
import ChevronLeftIcon from '@mui/icons-material/ChevronLeft';
import ChevronRightIcon from '@mui/icons-material/ChevronRight';
import { useAuth } from '../context/AuthContext';

const DRAWER_OPEN_WIDTH = 220;
const DRAWER_CLOSED_WIDTH = 68;

export default function Layout() {
  const { user, logout } = useAuth();
  const navigate = useNavigate();
  const location = useLocation();
  const [sidebarOpen, setSidebarOpen] = useState(true);

  const handleLogout = () => {
    logout();
    navigate('/login');
  };

  const navItems = [
    { label: 'Home', path: '/', icon: <HomeRoundedIcon /> },
    { label: 'Log Idea', path: '/ideas/new', icon: <AddCircleRoundedIcon /> },
    { label: 'All Ideas', path: '/ideas', icon: <ListAltRoundedIcon /> },
    { label: 'Profile', path: '/profile', icon: <PersonRoundedIcon /> },
  ];

  const drawerWidth = sidebarOpen ? DRAWER_OPEN_WIDTH : DRAWER_CLOSED_WIDTH;

  const ANNOUNCEMENT_HEIGHT = 32;
  const APPBAR_HEIGHT = 64;

  const announcements = [
    '🚀 Share your boldest ideas — innovation starts here!',
    '💡 Got a game-changing idea? Log it now and get feedback from the team!',
    '🔥 Top ideas get fast-tracked to development — make yours count!',
    '✨ New: Upvote & comment on ideas you love!',
    '🎯 NextGen Ideas — Where great ideas become great products',
  ];

  const marqueeText = announcements.join('   •   ');

  return (
    <Box sx={{ display: 'flex', flexDirection: 'column', minHeight: '100vh', bgcolor: 'background.default' }}>
      {/* Announcement marquee bar */}
      <Box
        sx={{
          position: 'fixed',
          top: 0,
          left: 0,
          right: 0,
          height: ANNOUNCEMENT_HEIGHT,
          zIndex: (theme) => theme.zIndex.drawer + 2,
          background: 'linear-gradient(90deg, #7C4DFF 0%, #00E5FF 50%, #7C4DFF 100%)',
          backgroundSize: '200% 100%',
          display: 'flex',
          alignItems: 'center',
          overflow: 'hidden',
          whiteSpace: 'nowrap',
          '@keyframes marquee': {
            '0%': { transform: 'translateX(0%)' },
            '100%': { transform: 'translateX(-50%)' },
          },
        }}
      >
        <Box
          sx={{
            display: 'inline-block',
            animation: 'marquee 60s linear infinite',
            color: '#fff',
            fontSize: '0.8rem',
            fontWeight: 600,
            letterSpacing: '0.03em',
          }}
        >
          {marqueeText + '   •   ' + marqueeText + '   •   '}
        </Box>
      </Box>

      {/* Full-width header on top */}
      <AppBar
        position="fixed"
        elevation={0}
        sx={{
          zIndex: (theme) => theme.zIndex.drawer + 1,
          top: ANNOUNCEMENT_HEIGHT,
          background: 'linear-gradient(135deg, #0D1321 0%, #151C30 50%, #0D1321 100%)',
          borderBottom: '1px solid rgba(0,229,255,0.12)',
          backdropFilter: 'blur(10px)',
        }}
      >
        <Toolbar sx={{ px: { xs: 2, md: 4 } }}>
          <Box
            sx={{ display: 'flex', alignItems: 'center', cursor: 'pointer' }}
            onClick={() => navigate('/')}
          >
            <AutoAwesomeIcon sx={{ mr: 1.5, fontSize: 34 }} />
            <Typography
              variant="h5"
              sx={{
                fontWeight: 800,
                letterSpacing: '-0.03em',
                background: 'linear-gradient(90deg, #00E5FF 0%, #7C4DFF 50%, #00E5FF 100%)',
                backgroundClip: 'text',
                WebkitBackgroundClip: 'text',
                WebkitTextFillColor: 'transparent',
                textShadow: 'none',
                fontSize: '1.6rem',
              }}
            >
              NextGen Ideas
            </Typography>
          </Box>

          <Box sx={{ flexGrow: 1 }} />

          {user && (
            <Box sx={{ display: 'flex', alignItems: 'center', gap: 2 }}>
              <Box
                onClick={() => navigate('/profile')}
                sx={{
                  display: 'flex', alignItems: 'center', gap: 1.5,
                  cursor: 'pointer',
                  py: 0.8, px: 2,
                  borderRadius: '50px',
                  background: 'linear-gradient(135deg, rgba(0,229,255,0.15), rgba(124,77,255,0.15))',
                  border: '1px solid rgba(0,229,255,0.25)',
                  transition: 'all 0.3s ease',
                  '&:hover': {
                    background: 'linear-gradient(135deg, rgba(0,229,255,0.25), rgba(124,77,255,0.25))',
                    borderColor: 'rgba(0,229,255,0.5)',
                    boxShadow: '0 4px 15px rgba(0,229,255,0.2)',
                  },
                }}
              >
                <Avatar
                  sx={{
                    width: 32, height: 32,
                    background: 'linear-gradient(135deg, #00E5FF, #7C4DFF)',
                    color: '#fff',
                    fontWeight: 800,
                    fontSize: '0.85rem',
                    boxShadow: '0 2px 8px rgba(0,229,255,0.4)',
                  }}
                >
                  {user.username.charAt(0).toUpperCase()}
                </Avatar>
                <Box>
                  <Typography sx={{ color: '#fff', fontWeight: 700, fontSize: '0.85rem', lineHeight: 1.2 }}>
                    {user.username}
                  </Typography>
                  {user.email && (
                    <Typography sx={{ color: 'rgba(255,255,255,0.5)', fontSize: '0.65rem', lineHeight: 1.2 }}>
                      {user.email}
                    </Typography>
                  )}
                </Box>
              </Box>
              <Tooltip title="Logout">
                <IconButton
                  onClick={handleLogout}
                  sx={{
                    color: '#fff',
                    background: 'rgba(255,82,82,0.15)',
                    border: '1px solid rgba(255,82,82,0.3)',
                    '&:hover': {
                      background: 'rgba(255,82,82,0.3)',
                      boxShadow: '0 4px 12px rgba(255,82,82,0.3)',
                    },
                  }}
                >
                  <LogoutIcon fontSize="small" />
                </IconButton>
              </Tooltip>
            </Box>
          )}
        </Toolbar>
      </AppBar>

      {/* Spacer for fixed AppBar + announcement bar */}
      <Toolbar sx={{ mt: `${ANNOUNCEMENT_HEIGHT}px` }} />

      {/* Sidebar + content row below the header */}
      <Box sx={{ display: 'flex', flexGrow: 1 }}>
        {/* Sidebar */}
        <Drawer
          variant="permanent"
          sx={{
            width: drawerWidth,
            flexShrink: 0,
            '& .MuiDrawer-paper': {
              width: drawerWidth,
              boxSizing: 'border-box',
              border: 'none',
              background: '#0F1525',
              boxShadow: '2px 0 20px rgba(0,0,0,0.3)',
              transition: 'width 0.25s ease',
              overflowX: 'hidden',
              top: APPBAR_HEIGHT + ANNOUNCEMENT_HEIGHT,
              height: `calc(100% - ${APPBAR_HEIGHT + ANNOUNCEMENT_HEIGHT}px)`,
              display: 'flex',
              flexDirection: 'column',
            },
          }}
        >
          {/* Nav items */}
          <List sx={{ px: sidebarOpen ? 1.5 : 0.8, mt: 1.5 }}>
            {navItems.map((item) => {
              const active = location.pathname === item.path;
              return (
                <Tooltip
                  key={item.path}
                  title={sidebarOpen ? '' : item.label}
                  placement="right"
                  arrow
                >
                  <ListItem disablePadding sx={{ mb: 0.5 }}>
                    <ListItemButton
                      onClick={() => navigate(item.path)}
                      sx={{
                        borderRadius: 3,
                        minHeight: 48,
                        px: sidebarOpen ? 2 : 0,
                        justifyContent: sidebarOpen ? 'initial' : 'center',
                      bgcolor: active ? 'linear-gradient(135deg, #00E5FF, #7C4DFF)' : 'transparent',
                      background: active ? 'linear-gradient(135deg, #00E5FF, #7C4DFF)' : 'transparent',
                      color: active ? '#fff' : 'text.primary',
                      boxShadow: active ? '0 4px 14px rgba(0,229,255,0.25)' : 'none',
                      '&:hover': {
                        bgcolor: active ? undefined : 'rgba(0,229,255,0.06)',
                        background: active ? 'linear-gradient(135deg, #00B2CC, #5A1FCB)' : 'rgba(0,229,255,0.06)',
                        },
                      }}
                    >
                      <ListItemIcon
                        sx={{
                          minWidth: 0,
                          mr: sidebarOpen ? 2 : 0,
                          justifyContent: 'center',
                          color: active ? '#fff' : '#00E5FF',
                        }}
                      >
                        {item.icon}
                      </ListItemIcon>
                      {sidebarOpen && (
                        <ListItemText
                          primary={item.label}
                          primaryTypographyProps={{
                            fontWeight: active ? 700 : 500,
                            fontSize: '0.9rem',
                          }}
                        />
                      )}
                    </ListItemButton>
                  </ListItem>
                </Tooltip>
              );
            })}
          </List>

          {/* Spacer to push toggle + year to bottom */}
          <Box sx={{ flexGrow: 1 }} />

          {/* Collapse toggle */}
          <Box
            sx={{
              display: 'flex',
              alignItems: 'center',
              justifyContent: sidebarOpen ? 'flex-end' : 'center',
              px: 1.5,
              pb: 1,
            }}
          >
            <IconButton
              onClick={() => setSidebarOpen(!sidebarOpen)}
              sx={{
                bgcolor: 'rgba(0,229,255,0.1)',
                color: '#00E5FF',
                '&:hover': { bgcolor: 'rgba(0,229,255,0.2)' },
                width: 34,
                height: 34,
              }}
            >
              {sidebarOpen ? <ChevronLeftIcon fontSize="small" /> : <ChevronRightIcon fontSize="small" />}
            </IconButton>
          </Box>

          {/* Copyright year */}
          {/* {sidebarOpen && (
          <Box
            sx={{
              textAlign: 'center',
              pb: 2,
              pt: 0.5,
            }}
          >
            <Typography
              variant="caption"
              sx={{ color: 'rgba(255,255,255,0.45)', fontSize: '0.75rem', display: 'block' }}
            >
              © NextGen Ideas
            </Typography>
            <Typography
              variant="caption"
              sx={{ color: 'rgba(255,255,255,0.3)', fontSize: '0.7rem' }}
            >
              {new Date().getFullYear()}
            </Typography>
          </Box>
          )} */}
        </Drawer>

        {/* Main content */}
        <Box sx={{ flexGrow: 1, display: 'flex', flexDirection: 'column' }}>
          <Container maxWidth="xl" sx={{ py: 5, flexGrow: 1 }}>
            <Outlet />
          </Container>
        </Box>
      </Box>
    </Box>
  );
}
