// Generated with GitHub Copilot - [Tracking ID: Hexure-Copilot]
import {
  Dialog,
  DialogTitle,
  DialogContent,
  DialogActions,
  Button,
  Typography,
  Box,
  Card,
  CardContent,
  Chip,
  Alert,
  IconButton,
} from '@mui/material';
import CloseIcon from '@mui/icons-material/Close';
import WarningIcon from '@mui/icons-material/Warning';
import InfoIcon from '@mui/icons-material/Info';
import CheckCircleIcon from '@mui/icons-material/CheckCircle';

/**
 * Modal to display similar ideas found during duplicate checking
 * @param {boolean} open - Whether modal is visible
 * @param {Object} duplicateResult - Result from duplicate check API
 * @param {Function} onClose - Callback when modal is closed
 * @param {Function} onProceed - Callback when user wants to proceed anyway
 */
export default function SimilarIdeasModal({ open, duplicateResult, onClose, onProceed }) {
  if (!duplicateResult?.hasSimilar) {
    return null;
  }

  const { similarIdeas, totalSimilar, suggestion } = duplicateResult;

  // Determine severity based on highest similarity score
  const highestScore = similarIdeas[0]?.similarityScore || 0;
  const getSeverityInfo = (score) => {
    if (score >= 0.90) {
      return {
        color: 'error',
        icon: <WarningIcon />,
        severity: 'error'
      };
    }
    if (score >= 0.85) {
      return {
        color: 'warning',
        icon: <InfoIcon />,
        severity: 'warning'
      };
    }
    return {
      color: 'info',
      icon: <InfoIcon />,
      severity: 'info'
    };
  };

  const severityInfo = getSeverityInfo(highestScore);

  const getScoreColor = (score) => {
    if (score >= 0.90) return 'error';
    if (score >= 0.85) return 'warning';
    return 'info';
  };

  return (
    <Dialog
      open={open}
      onClose={onClose}
      maxWidth="md"
      fullWidth
      PaperProps={{
        sx: { borderRadius: 2 }
      }}
    >
      {/* Header */}
      <DialogTitle
        sx={{
          bgcolor: severityInfo.color === 'error' ? 'error.light' :
                  severityInfo.color === 'warning' ? 'warning.light' : 'info.light',
          color: severityInfo.color === 'error' ? 'error.contrastText' :
                 severityInfo.color === 'warning' ? 'warning.contrastText' : 'info.contrastText',
          display: 'flex',
          alignItems: 'center',
          justifyContent: 'space-between',
          pb: 2
        }}
      >
        <Box display="flex" alignItems="center" gap={1.5}>
          {severityInfo.icon}
          <Box>
            <Typography variant="h6" component="div" fontWeight="bold">
              Similar Ideas Found
            </Typography>
            <Typography variant="body2" sx={{ opacity: 0.9 }}>
              Found {totalSimilar} similar idea{totalSimilar !== 1 ? 's' : ''}
            </Typography>
          </Box>
        </Box>
        <IconButton
          onClick={onClose}
          sx={{
            color: 'inherit',
            '&:hover': { bgcolor: 'rgba(255,255,255,0.2)' }
          }}
        >
          <CloseIcon />
        </IconButton>
      </DialogTitle>

      {/* Content */}
      <DialogContent sx={{ pt: 3 }}>
        {/* Suggestion Alert */}
        <Alert severity={severityInfo.severity} sx={{ mb: 3 }}>
          <Typography fontWeight="medium">{suggestion}</Typography>
        </Alert>

        {/* Similar Ideas List */}
        <Box sx={{ display: 'flex', flexDirection: 'column', gap: 2 }}>
          {similarIdeas.map((idea) => (
            <Card
              key={idea.ideaId}
              variant="outlined"
              sx={{
                transition: 'box-shadow 0.2s',
                '&:hover': {
                  boxShadow: 3
                }
              }}
            >
              <CardContent>
                {/* Header with title and score */}
                <Box display="flex" justifyContent="space-between" alignItems="start" mb={1}>
                  <Box flex={1}>
                    <Typography variant="h6" fontWeight="bold" gutterBottom>
                      {idea.title}
                    </Typography>
                    {idea.categoryName && (
                      <Chip
                        label={idea.categoryName}
                        size="small"
                        sx={{ mt: 0.5 }}
                      />
                    )}
                  </Box>
                  <Box ml={2} display="flex" flexDirection="column" alignItems="flex-end">
                    <Chip
                      label={`${(idea.similarityScore * 100).toFixed(0)}% Match`}
                      color={getScoreColor(idea.similarityScore)}
                      sx={{ fontWeight: 'bold' }}
                    />
                    <Typography variant="caption" color="text.secondary" mt={0.5}>
                      {idea.matchReason}
                    </Typography>
                  </Box>
                </Box>

                {/* Description */}
                {idea.description && (
                  <Typography
                    variant="body2"
                    color="text.secondary"
                    sx={{
                      mt: 1,
                      display: '-webkit-box',
                      WebkitLineClamp: 3,
                      WebkitBoxOrient: 'vertical',
                      overflow: 'hidden'
                    }}
                  >
                    {idea.description}
                  </Typography>
                )}

                {/* Metadata */}
                {idea.createdAt && (
                  <Box display="flex" gap={2} mt={2}>
                    <Typography variant="caption" color="text.secondary">
                      Created: {new Date(idea.createdAt).toLocaleDateString()}
                    </Typography>
                    {idea.createdBy && (
                      <Typography variant="caption" color="text.secondary">
                        By: {idea.createdBy}
                      </Typography>
                    )}
                  </Box>
                )}
              </CardContent>
            </Card>
          ))}
        </Box>

        {/* Warning for high similarity */}
        {highestScore >= 0.90 && (
          <Alert severity="error" icon={<WarningIcon />} sx={{ mt: 3 }}>
            <Typography variant="body2" fontWeight="bold" gutterBottom>
              Almost Identical Idea
            </Typography>
            <Typography variant="body2">
              This idea is very similar to an existing one. Consider reviewing or collaborating instead of creating a duplicate.
            </Typography>
          </Alert>
        )}
      </DialogContent>

      {/* Footer */}
      <DialogActions sx={{ px: 3, pb: 2, gap: 1 }}>
        <Button onClick={onClose} variant="outlined" size="large">
          Review & Edit
        </Button>
        <Button
          onClick={onProceed}
          variant="contained"
          size="large"
          color={highestScore >= 0.90 ? 'error' : 'primary'}
        >
          {highestScore >= 0.90 ? 'Proceed Anyway' : 'Continue with My Idea'}
        </Button>
      </DialogActions>
    </Dialog>
  );
}
