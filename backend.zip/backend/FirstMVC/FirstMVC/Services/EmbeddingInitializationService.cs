// Generated with GitHub Copilot - [Tracking ID: Hexure-Copilot]
using FirstMVC.Services.Interfaces;
using FirstMVC.Models.Configuration;
using Microsoft.Extensions.Options;

namespace FirstMVC.Services
{
    /// <summary>
    /// Background service that initializes embedding system on application startup
    /// 
    /// WHAT THIS SERVICE DOES:
    /// 1. Loads the ONNX model when app starts
    /// 2. Indexes all existing ideas from database
    /// 3. Makes duplicate detection ready to use
    /// 
    /// WHEN IT RUNS: Automatically when app starts (background task)
    /// 
    /// This implements IHostedService - a special .NET interface for background tasks
    /// </summary>
    public class EmbeddingInitializationService : IHostedService
    {
        private readonly IServiceProvider _serviceProvider;
        private readonly EmbeddingConfig _config;
        private readonly ILogger<EmbeddingInitializationService> _logger;

        /// <summary>
        /// Constructor - .NET will inject these automatically
        /// </summary>
        public EmbeddingInitializationService(
            IServiceProvider serviceProvider,
            IOptions<EmbeddingConfig> config,
            ILogger<EmbeddingInitializationService> logger)
        {
            _serviceProvider = serviceProvider;
            _config = config.Value;
            _logger = logger;
        }

        /// <summary>
        /// StartAsync - Called automatically when app starts
        /// This is where we do all the initialization work
        /// 
        /// PROCESS:
        /// 1. Initialize ONNX model (1-3 seconds)
        /// 2. Load existing ideas (varies based on count)
        /// 3. Log success or failure
        /// 
        /// IMPORTANT: This runs in the background, so your app starts quickly!
        /// Users can access the app while this finishes in the background.
        /// </summary>
        public async Task StartAsync(CancellationToken cancellationToken)
        {
            _logger.LogInformation("🚀 Starting Embedding Initialization Service...");
            _logger.LogInformation("═══════════════════════════════════════════════════");

            try
            {
                // Create a scope to get scoped services
                // Why? Singleton services can't directly inject scoped services
                using var scope = _serviceProvider.CreateScope();
                
                // Get our services
                var embeddingService = scope.ServiceProvider.GetRequiredService<IEmbeddingService>();
                var vectorStoreService = scope.ServiceProvider.GetRequiredService<IVectorStoreService>();

                // === STEP 1: Initialize ONNX Model ===
                _logger.LogInformation("📦 Step 1/2: Initializing ONNX embedding model...");
                
                var startTime = DateTime.UtcNow;
                await embeddingService.InitializeAsync();
                var elapsed = (DateTime.UtcNow - startTime).TotalSeconds;
                
                _logger.LogInformation("✅ ONNX model initialized successfully ({Elapsed:F1}s)", elapsed);

                // === STEP 2: Load Existing Ideas (if configured) ===
                if (_config.AutoLoadOnStartup)
                {
                    _logger.LogInformation("📦 Step 2/2: Loading existing ideas into vector store...");
                    _logger.LogInformation("⏳ This may take a while for large databases...");
                    
                    startTime = DateTime.UtcNow;
                    var count = await vectorStoreService.LoadExistingIdeasAsync();
                    elapsed = (DateTime.UtcNow - startTime).TotalSeconds;
                    
                    _logger.LogInformation("✅ Loaded {Count} ideas into vector store ({Elapsed:F1}s)", count, elapsed);
                    
                    if (count > 0)
                    {
                        _logger.LogInformation("💡 Average time per idea: {AvgTime:F0}ms", (elapsed * 1000) / count);
                    }
                }
                else
                {
                    _logger.LogInformation("⏭️ Step 2/2: Auto-load disabled, skipping existing ideas");
                }

                // === SUCCESS! ===
                _logger.LogInformation("═══════════════════════════════════════════════════");
                _logger.LogInformation("✅ Embedding system ready for duplicate detection!");
                _logger.LogInformation("🎯 Similarity threshold: {Threshold:P0}", _config.SimilarityThreshold);
                _logger.LogInformation("🔢 Max results: {MaxResults}", _config.MaxResults);
                _logger.LogInformation("═══════════════════════════════════════════════════");
            }
            catch (Exception ex)
            {
                // === FAILURE ===
                _logger.LogError(ex, "❌ Failed to initialize embedding system");
                _logger.LogWarning("⚠️ Application will continue, but duplicate detection may not work");
                _logger.LogWarning("⚠️ Check the error above and verify:");
                _logger.LogWarning("   1. model.onnx file exists at: {ModelPath}", _config.ModelPath);
                _logger.LogWarning("   2. Database connection is working");
                _logger.LogWarning("   3. Required NuGet packages are installed");
                
                // Don't throw - allow app to start even if embedding fails
                // This way you can still use other features of your app
            }
        }

        /// <summary>
        /// StopAsync - Called automatically when app shuts down
        /// We don't need to do anything special here
        /// </summary>
        public Task StopAsync(CancellationToken cancellationToken)
        {
            _logger.LogInformation("🛑 Stopping Embedding Initialization Service...");
            return Task.CompletedTask;
        }
    }
}
