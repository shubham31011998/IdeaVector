// Generated with GitHub Copilot - [Tracking ID: Hexure-Copilot]
using System.Collections.Concurrent;
using FirstMVC.Data;
using FirstMVC.Models.Configuration;
using FirstMVC.Models.DTOs;
using FirstMVC.Models.MLModels;
using FirstMVC.Services.Interfaces;
using Microsoft.EntityFrameworkCore;
using Microsoft.Extensions.Options;

namespace FirstMVC.Services
{
    /// <summary>
    /// In-memory vector store for semantic similarity search
    /// 
    /// WHAT THIS SERVICE DOES:
    /// 1. Stores idea embeddings in RAM (fast!)
    /// 2. Searches for similar vectors using cosine similarity
    /// 3. Returns top matching ideas
    /// 
    /// Think of it as a specialized in-memory database for vectors
    /// </summary>
    public class VectorStoreService : IVectorStoreService
    {
        // === IN-MEMORY STORAGE ===
        // ConcurrentDictionary = Thread-safe dictionary
        // Key = IdeaId (e.g., 42)
        // Value = IdeaEmbedding (contains the vector)
        private readonly ConcurrentDictionary<int, IdeaEmbedding> _embeddings;
        
        // === DEPENDENCIES ===
        private readonly IEmbeddingService _embeddingService;
        private readonly IServiceScopeFactory _scopeFactory;
        private readonly EmbeddingConfig _config;
        private readonly ILogger<VectorStoreService> _logger;
        
        // === STATE ===
        private readonly SemaphoreSlim _loadLock = new(1, 1);
        private bool _isLoaded;

        /// <summary>
        /// Constructor - called by .NET dependency injection
        /// </summary>
        public VectorStoreService(
            IEmbeddingService embeddingService,
            IServiceScopeFactory scopeFactory,
            IOptions<EmbeddingConfig> config,
            ILogger<VectorStoreService> logger)
        {
            _embeddings = new ConcurrentDictionary<int, IdeaEmbedding>();
            _embeddingService = embeddingService;
            _scopeFactory = scopeFactory;
            _config = config.Value;
            _logger = logger;
        }

        /// <summary>
        /// STEP 1: Add or update an embedding in the store
        /// 
        /// WHAT HAPPENS:
        /// - Stores the vector in memory
        /// - If idea already exists, updates it
        /// - Thread-safe (multiple requests can call simultaneously)
        /// 
        /// WHEN CALLED: After creating/updating an idea
        /// </summary>
        public async Task AddOrUpdateAsync(int ideaId, float[] embedding, string combinedText, 
            string? categoryName = null, string? createdBy = null)
        {
            // Validation: Check embedding size is correct
            if (embedding == null || embedding.Length != _config.ModelDimensions)
            {
                throw new ArgumentException(
                    $"Embedding must be {_config.ModelDimensions} dimensions", 
                    nameof(embedding));
            }

            // Create the object to store
            var ideaEmbedding = new IdeaEmbedding
            {
                IdeaId = ideaId,
                Embedding = embedding,
                CombinedText = combinedText,
                CreatedAt = DateTime.UtcNow,
                CategoryName = categoryName,
                CreatedBy = createdBy
            };

            // Store in dictionary (AddOrUpdate = insert or replace)
            _embeddings.AddOrUpdate(ideaId, ideaEmbedding, (key, existing) => ideaEmbedding);

            _logger.LogDebug("✅ Added/updated embedding for idea {IdeaId}", ideaId);
            
            await Task.CompletedTask; // Make method async
        }

        /// <summary>
        /// STEP 2: Find similar ideas (THE CORE SEARCH METHOD!)
        /// 
        /// WHAT HAPPENS:
        /// 1. Compare query vector with ALL stored vectors
        /// 2. Calculate cosine similarity for each
        /// 3. Filter by threshold (e.g., >0.85)
        /// 4. Sort by similarity (highest first)
        /// 5. Return top K results
        /// 
        /// THIS IS WHERE THE MAGIC HAPPENS!
        /// </summary>
        public async Task<List<SimilarityResult>> FindSimilarAsync(
            float[] queryEmbedding, 
            int topK = 5, 
            double threshold = 0.85, 
            int? excludeIdeaId = null)
        {
            // Validation
            if (queryEmbedding == null || queryEmbedding.Length != _config.ModelDimensions)
            {
                throw new ArgumentException(
                    $"Query embedding must be {_config.ModelDimensions} dimensions", 
                    nameof(queryEmbedding));
            }

            var results = new List<(int IdeaId, double Similarity)>();

            // === THE SEARCH: Compare with every stored embedding ===
            foreach (var kvp in _embeddings)
            {
                // Skip excluded idea (e.g., when editing, don't match itself)
                if (excludeIdeaId.HasValue && kvp.Key == excludeIdeaId.Value)
                    continue;

                // CALCULATE SIMILARITY!
                // This is the key operation - comparing two vectors
                var similarity = CalculateCosineSimilarity(queryEmbedding, kvp.Value.Embedding);

                // Only include if above threshold
                if (similarity >= threshold)
                {
                    results.Add((kvp.Key, similarity));
                }
            }

            // Sort by similarity (highest first) and take top K
            var topResults = results
                .OrderByDescending(r => r.Similarity)
                .Take(topK)
                .ToList();

            // If no results, return empty list
            if (!topResults.Any())
            {
                return new List<SimilarityResult>();
            }

            // Fetch full idea details from database
            var similarityResults = await GetIdeaDetailsAsync(topResults);

            _logger.LogInformation(
                "🔍 Found {Count} similar ideas (threshold: {Threshold})", 
                similarityResults.Count, 
                threshold);

            return similarityResults;
        }

        /// <summary>
        /// STEP 3: Remove an embedding from the store
        /// WHEN CALLED: When an idea is deleted
        /// </summary>
        public async Task<bool> RemoveAsync(int ideaId)
        {
            var removed = _embeddings.TryRemove(ideaId, out _);
            
            if (removed)
            {
                _logger.LogDebug("🗑️ Removed embedding for idea {IdeaId}", ideaId);
            }

            await Task.CompletedTask;
            return removed;
        }

        /// <summary>
        /// STEP 4: Get count of stored embeddings
        /// </summary>
        public Task<int> GetCountAsync()
        {
            return Task.FromResult(_embeddings.Count);
        }

        /// <summary>
        /// STEP 5: Load all existing ideas from database (ONE-TIME OPERATION)
        /// 
        /// WHAT HAPPENS:
        /// 1. Read all ideas from SQL Server
        /// 2. For each idea:
        ///    - Generate embedding
        ///    - Store in memory
        /// 3. Log progress
        /// 
        /// WHEN CALLED: Automatically on app startup
        /// PERFORMANCE: ~50ms per idea (10 ideas = ~500ms, 100 ideas = ~5 seconds)
        /// </summary>
        public async Task<int> LoadExistingIdeasAsync()
        {
            // Quick exit if already loaded
            if (_isLoaded && _embeddings.Any())
            {
                _logger.LogInformation("📦 Embeddings already loaded ({Count} ideas)", _embeddings.Count);
                return _embeddings.Count;
            }

            await _loadLock.WaitAsync();
            try
            {
                // Check if embedding service is ready
                if (!_embeddingService.IsInitialized)
                {
                    _logger.LogWarning("⚠️ Embedding service not initialized, skipping auto-load");
                    return 0;
                }

                _logger.LogInformation("🔄 Loading existing ideas from database...");

                // Create a database context
                using var scope = _scopeFactory.CreateScope();
                var dbContext = scope.ServiceProvider.GetRequiredService<ApplicationDbContext>();

                // Load all ideas from database
                // Note: Loading without Include first, can add category lookup later if needed
                var ideas = await dbContext.Ideas.ToListAsync();

                _logger.LogInformation("📊 Found {Count} ideas to index", ideas.Count);

                int indexed = 0;
                int failed = 0;

                // Process each idea
                foreach (var idea in ideas)
                {
                    try
                    {
                        // Combine title + description
                        var combinedText = _embeddingService.CombineTextFields(
                            idea.Title, 
                            idea.Description ?? string.Empty);

                        // Generate embedding
                        var embedding = await _embeddingService.GenerateEmbeddingAsync(combinedText);

                        // Store in memory
                        await AddOrUpdateAsync(
                            idea.IdeaId, 
                            embedding, 
                            combinedText, 
                            null, // Category name - can be added later if needed
                            idea.CreatedBy.ToString());

                        indexed++;

                        // Log progress every 10 ideas
                        if (indexed % 10 == 0)
                        {
                            _logger.LogInformation("⏳ Indexed {Indexed}/{Total} ideas", indexed, ideas.Count);
                        }
                    }
                    catch (Exception ex)
                    {
                        _logger.LogError(ex, "❌ Failed to index idea {IdeaId}", idea.IdeaId);
                        failed++;
                    }
                }

                _isLoaded = true;

                _logger.LogInformation(
                    "✅ Indexing complete: {Indexed} successful, {Failed} failed", 
                    indexed, failed);

                return indexed;
            }
            finally
            {
                _loadLock.Release();
            }
        }

        /// <summary>
        /// STEP 6: Clear all embeddings
        /// </summary>
        public Task ClearAsync()
        {
            _embeddings.Clear();
            _isLoaded = false;
            _logger.LogInformation("🗑️ Cleared all embeddings");
            return Task.CompletedTask;
        }

        /// <summary>
        /// STEP 7: Get a single embedding by ID
        /// </summary>
        public Task<IdeaEmbedding?> GetByIdAsync(int ideaId)
        {
            _embeddings.TryGetValue(ideaId, out var embedding);
            return Task.FromResult(embedding);
        }

        // ============================================================
        // HELPER METHODS (Internal Implementation)
        // ============================================================

        /// <summary>
        /// Calculates cosine similarity between two vectors
        /// 
        /// FORMULA: similarity = (A · B) / (|A| × |B|)
        /// 
        /// Since our vectors are normalized (length = 1):
        /// similarity = A · B (dot product)
        /// 
        /// RESULT:
        /// - 1.0 = Identical
        /// - 0.9+ = Very similar
        /// - 0.8-0.9 = Similar
        /// - <0.8 = Different
        /// 
        /// THIS IS THE CORE MATH THAT FINDS DUPLICATES!
        /// </summary>
        private double CalculateCosineSimilarity(float[] vectorA, float[] vectorB)
        {
            if (vectorA.Length != vectorB.Length)
            {
                throw new ArgumentException("Vectors must have the same dimensions");
            }

            // Calculate dot product
            // Dot product = sum of (A[i] × B[i])
            double dotProduct = 0;
            for (int i = 0; i < vectorA.Length; i++)
            {
                dotProduct += vectorA[i] * vectorB[i];
            }

            // Since vectors are normalized (length = 1), dot product IS the cosine similarity!
            return dotProduct;
        }

        /// <summary>
        /// Fetches full idea details from database for similarity results
        /// 
        /// WHAT HAPPENS:
        /// 1. We have list of (IdeaId, Similarity) pairs
        /// 2. Query database to get full idea info (title, description, etc.)
        /// 3. Create SimilarityResult DTOs
        /// 4. Return to caller
        /// </summary>
        private async Task<List<SimilarityResult>> GetIdeaDetailsAsync(
            List<(int IdeaId, double Similarity)> similarityScores)
        {
            using var scope = _scopeFactory.CreateScope();
            var dbContext = scope.ServiceProvider.GetRequiredService<ApplicationDbContext>();

            var ideaIds = similarityScores.Select(s => s.IdeaId).ToList();

            // Query database for idea details
            var ideas = await dbContext.Ideas

                .Where(i => ideaIds.Contains(i.IdeaId))
                .ToDictionaryAsync(i => i.IdeaId);

            var results = new List<SimilarityResult>();

            // Create result objects
            foreach (var (ideaId, similarity) in similarityScores)
            {
                if (ideas.TryGetValue(ideaId, out var idea))
                {
                    results.Add(new SimilarityResult
                    {
                        IdeaId = idea.IdeaId,
                        Title = idea.Title,
                        Description = idea.Description ?? string.Empty,
                        SimilarityScore = similarity,
                        MatchReason = GetMatchReason(similarity),
                        CategoryName = null, // Can be added later if needed
                        CreatedAt = idea.CreatedDate
                    });
                }
            }

            return results;
        }

        /// <summary>
        /// Generates human-readable match reason based on similarity score
        /// 
        /// Translates numbers into words:
        /// 0.95 → "Almost identical - Very likely duplicate"
        /// 0.89 → "Very similar - Possibly duplicate"
        /// 0.82 → "Similar content - Worth reviewing"
        /// </summary>
        private string GetMatchReason(double similarity)
        {
            return similarity switch
            {
                >= 0.95 => "Almost identical - Very likely duplicate",
                >= 0.90 => "Very similar - Possibly duplicate",
                >= 0.85 => "Similar content - Worth reviewing",
                >= 0.80 => "Somewhat similar - May be related",
                _ => "Related idea"
            };
        }
    }
}
