// Generated with GitHub Copilot - [Tracking ID: Hexure-Copilot]
using Microsoft.ML.OnnxRuntime;
using Microsoft.ML.OnnxRuntime.Tensors;
using FirstMVC.Services.Interfaces;
using FirstMVC.Models.Configuration;
using Microsoft.Extensions.Options;
using System.Text;
using System.Text.RegularExpressions;

namespace FirstMVC.Services
{
    /// <summary>
    /// Service for generating text embeddings using ONNX Runtime
    /// Uses the all-MiniLM-L6-v2 model for semantic similarity
    /// 
    /// WHAT THIS SERVICE DOES:
    /// Input:  "AI dashboard for ticket analytics" (text)
    /// Output: [0.234, -0.156, 0.872, ..., 0.421] (384 numbers)
    /// 
    /// These numbers capture the MEANING of the text!
    /// Similar meanings = similar numbers = high cosine similarity
    /// </summary>
    public class EmbeddingService : IEmbeddingService, IDisposable
    {
        // === DEPENDENCIES (Injected by .NET) ===
        private readonly EmbeddingConfig _config;
        private readonly ILogger<EmbeddingService> _logger;
        
        // === ONNX MODEL STATE ===
        private Microsoft.ML.OnnxRuntime.InferenceSession? _session;  // The loaded ONNX model
        private readonly SemaphoreSlim _initLock = new(1, 1);  // Thread-safe initialization
        private bool _isInitialized;
        
        // === MODEL CONSTANTS ===
        // These values are specific to the all-MiniLM-L6-v2 model
        private const int MaxSequenceLength = 128;  // Max tokens to process
        private const int PadTokenId = 0;           // [PAD] token
        private const int ClsTokenId = 101;         // [CLS] token (start)
        private const int SepTokenId = 102;         // [SEP] token (end)
        
        // === SIMPLE VOCABULARY ===
        // In production, this would be a full BERT vocabulary file (30K+ words)
        // For learning purposes, we're using a simplified version
        private readonly Dictionary<string, int> _vocabulary;

        /// <summary>
        /// Whether the model is loaded and ready
        /// </summary>
        public bool IsInitialized => _isInitialized;

        /// <summary>
        /// Constructor - called by .NET dependency injection
        /// </summary>
        public EmbeddingService(
            IOptions<EmbeddingConfig> config,
            ILogger<EmbeddingService> logger)
        {
            _config = config.Value;
            _logger = logger;
            _vocabulary = InitializeVocabulary();
        }

        /// <summary>
        /// STEP 1: Initialize the ONNX model
        /// This loads the model.onnx file and prepares it for inference
        /// 
        /// WHEN CALLED: Once at application startup
        /// PERFORMANCE: Takes 1-3 seconds the first time
        /// </summary>
        public async Task InitializeAsync()
        {
            // Quick exit if already initialized
            if (_isInitialized) return;

            // Use lock to ensure only one thread initializes
            await _initLock.WaitAsync();
            try
            {
                // Double-check after acquiring lock
                if (_isInitialized) return;

                _logger.LogInformation("🔄 Initializing ONNX embedding model from {ModelPath}", _config.ModelPath);

                // STEP 1.1: Check if model file exists
                if (!File.Exists(_config.ModelPath))
                {
                    throw new FileNotFoundException($"ONNX model not found at: {_config.ModelPath}");
                }

                // STEP 1.2: Configure ONNX Runtime
                var sessionOptions = new Microsoft.ML.OnnxRuntime.SessionOptions
                {
                    GraphOptimizationLevel = Microsoft.ML.OnnxRuntime.GraphOptimizationLevel.ORT_ENABLE_ALL,  // Optimize for speed
                    ExecutionMode = Microsoft.ML.OnnxRuntime.ExecutionMode.ORT_PARALLEL                        // Use multiple threads
                };

                // STEP 1.3: Load the ONNX model into memory
                _session = new Microsoft.ML.OnnxRuntime.InferenceSession(_config.ModelPath, sessionOptions);

                // STEP 1.4: Warm up the model (first run is slower)
                await WarmUpModelAsync();

                _isInitialized = true;
                _logger.LogInformation("✅ ONNX model initialized successfully");
            }
            catch (Exception ex)
            {
                _logger.LogError(ex, "❌ Failed to initialize ONNX model");
                throw;
            }
            finally
            {
                _initLock.Release();
            }
        }

        /// <summary>
        /// STEP 2: Generate embedding from text
        /// This is the MAIN method that converts text into vectors
        /// 
        /// PROCESS:
        /// 1. Preprocess text (lowercase, cleanup)
        /// 2. Tokenize (convert words to numbers)
        /// 3. Run through ONNX model
        /// 4. Normalize the output vector
        /// 5. Return 384 numbers
        /// 
        /// PERFORMANCE: ~20-50ms per text after warm-up
        /// </summary>
        public async Task<float[]> GenerateEmbeddingAsync(string text)
        {
            // Validation: Ensure service is ready
            if (!_isInitialized)
            {
                throw new InvalidOperationException("Service not initialized. Call InitializeAsync first.");
            }

            if (string.IsNullOrWhiteSpace(text))
            {
                throw new ArgumentException("Text cannot be empty", nameof(text));
            }

            try
            {
                // STEP 2.1: Preprocess text
                var processedText = PreprocessText(text);

                // STEP 2.2: Tokenize (convert to numbers)
                var tokenIds = Tokenize(processedText);

                // STEP 2.3: Create input tensors for ONNX model
                var inputTensor = CreateInputTensor(tokenIds);
                var attentionMask = CreateAttentionMask(tokenIds);
                var tokenTypeIds = CreateTokenTypeIds(tokenIds);  // ✅ Add this!

                // STEP 2.4: Run inference (the AI model processes it)
                var embedding = await Task.Run(() => RunInference(inputTensor, attentionMask, tokenTypeIds));

                // STEP 2.5: Normalize vector for cosine similarity
                NormalizeVector(embedding);

                return embedding;
            }
            catch (Exception ex)
            {
                _logger.LogError(ex, "❌ Error generating embedding for text: {Text}", 
                    text.Substring(0, Math.Min(50, text.Length)));
                throw;
            }
        }

        /// <summary>
        /// STEP 3: Generate embedding for an idea (convenience method)
        /// Combines title and description before embedding
        /// </summary>
        public async Task<float[]> GenerateIdeaEmbeddingAsync(string title, string description)
        {
            var combinedText = CombineTextFields(title, description);
            return await GenerateEmbeddingAsync(combinedText);
        }

        /// <summary>
        /// STEP 4: Combine text fields consistently
        /// Format: "Title: {title}. Description: {description}"
        /// </summary>
        public string CombineTextFields(string title, string description)
        {
            var combined = new StringBuilder();
            
            if (!string.IsNullOrWhiteSpace(title))
            {
                combined.Append("Title: ").Append(title.Trim());
            }

            if (!string.IsNullOrWhiteSpace(description))
            {
                if (combined.Length > 0)
                    combined.Append(". ");
                combined.Append("Description: ").Append(description.Trim());
            }

            var result = combined.ToString();
            
            // Truncate if too long
            if (result.Length > _config.MaxTextLength)
            {
                result = result.Substring(0, _config.MaxTextLength);
            }

            return result;
        }

        // ============================================================
        // HELPER METHODS (Internal Implementation Details)
        // You don't need to understand every detail here!
        // These are the "behind the scenes" operations
        // ============================================================

        /// <summary>
        /// Preprocesses text before tokenization
        /// - Convert to lowercase
        /// - Remove extra whitespace
        /// - Basic cleanup
        /// </summary>
        private string PreprocessText(string text)
        {
            // Convert to lowercase (models are case-insensitive)
            text = text.ToLowerInvariant();

            // Remove extra whitespace
            text = Regex.Replace(text, @"\s+", " ").Trim();

            return text;
        }

        /// <summary>
        /// Tokenizes text (converts words to token IDs)
        /// 
        /// Example:
        /// "ai dashboard" → [101, 2000, 2001, 102, 0, 0, ..., 0]
        /// 
        /// NOTE: This is a SIMPLIFIED tokenizer for learning purposes
        /// Production would use BertTokenizer or similar
        /// </summary>
        private int[] Tokenize(string text)
        {
            var words = text.Split(' ', StringSplitOptions.RemoveEmptyEntries);
            var tokens = new List<int> { ClsTokenId }; // Start with [CLS]

            foreach (var word in words)
            {
                if (tokens.Count >= MaxSequenceLength - 1) break;

                // Try to get token ID from vocabulary
                if (_vocabulary.TryGetValue(word, out int tokenId))
                {
                    tokens.Add(tokenId);
                }
                else
                {
                    // Unknown word: Use a hash-based ID
                    tokenId = Math.Abs(word.GetHashCode() % 10000) + 1000;
                    tokens.Add(tokenId);
                }
            }

            tokens.Add(SepTokenId); // End with [SEP]

            // Pad to MaxSequenceLength
            while (tokens.Count < MaxSequenceLength)
            {
                tokens.Add(PadTokenId);
            }

            return tokens.ToArray();
        }

        /// <summary>
        /// Creates input tensor for ONNX model
        /// Tensor = multi-dimensional array
        /// Shape: [1, 128] (1 batch, 128 tokens)
        /// </summary>
        private DenseTensor<long> CreateInputTensor(int[] tokenIds)
        {
            var tensor = new DenseTensor<long>(new[] { 1, MaxSequenceLength });
            for (int i = 0; i < tokenIds.Length; i++)
            {
                tensor[0, i] = tokenIds[i];
            }
            return tensor;
        }

        /// <summary>
        /// Creates attention mask tensor
        /// Tells model which tokens are real (1) vs padding (0)
        /// </summary>
        private DenseTensor<long> CreateAttentionMask(int[] tokenIds)
        {
            var tensor = new DenseTensor<long>(new[] { 1, MaxSequenceLength });
            for (int i = 0; i < tokenIds.Length; i++)
            {
                tensor[0, i] = tokenIds[i] != PadTokenId ? 1 : 0;
            }
            return tensor;
        }

        /// <summary>
        /// Creates token type IDs tensor
        /// For single sentence tasks, this is all zeros
        /// </summary>
        private DenseTensor<long> CreateTokenTypeIds(int[] tokenIds)
        {
            var tensor = new DenseTensor<long>(new[] { 1, MaxSequenceLength });
            // All zeros for single sentence (no sentence pairs)
            for (int i = 0; i < tokenIds.Length; i++)
            {
                tensor[0, i] = 0;
            }
            return tensor;
        }

        /// <summary>
        /// Runs inference through the ONNX model
        /// This is where the AI magic happens!
        /// 
        /// INPUT: Token IDs, attention mask, and token type IDs
        /// OUTPUT: 384-dimensional embedding
        /// </summary>
        private float[] RunInference(DenseTensor<long> inputIds, DenseTensor<long> attentionMask, DenseTensor<long> tokenTypeIds)
        {
            if (_session == null)
                throw new InvalidOperationException("Model session is not initialized");

            // Create inputs for the model
            var inputs = new List<NamedOnnxValue>
            {
                NamedOnnxValue.CreateFromTensor("input_ids", inputIds),
                NamedOnnxValue.CreateFromTensor("attention_mask", attentionMask),
                NamedOnnxValue.CreateFromTensor("token_type_ids", tokenTypeIds)
            };

            // Run the model!
            using var results = _session.Run(inputs);
            
            // Get output tensor
            var outputTensor = results.First().AsEnumerable<float>().ToArray();

            // Apply mean pooling to get final embedding
            var embedding = MeanPooling(outputTensor, attentionMask);

            return embedding;
        }

        /// <summary>
        /// Mean pooling: Average the token embeddings
        /// Converts many token vectors into one sentence vector
        /// </summary>
        private float[] MeanPooling(float[] tokenEmbeddings, DenseTensor<long> attentionMask)
        {
            var embeddingDim = _config.ModelDimensions;
            var numTokens = MaxSequenceLength;
            var result = new float[embeddingDim];

            int validTokens = 0;
            for (int token = 0; token < numTokens; token++)
            {
                if (attentionMask[0, token] == 1)
                {
                    validTokens++;
                    for (int dim = 0; dim < embeddingDim; dim++)
                    {
                        int idx = token * embeddingDim + dim;
                        if (idx < tokenEmbeddings.Length)
                        {
                            result[dim] += tokenEmbeddings[idx];
                        }
                    }
                }
            }

            // Average
            if (validTokens > 0)
            {
                for (int dim = 0; dim < embeddingDim; dim++)
                {
                    result[dim] /= validTokens;
                }
            }

            return result;
        }

        /// <summary>
        /// Normalizes vector to unit length
        /// Required for cosine similarity to work correctly
        /// 
        /// After normalization: vector length = 1.0
        /// </summary>
        private void NormalizeVector(float[] vector)
        {
            // Calculate magnitude (length)
            double sumSquares = 0;
            foreach (var val in vector)
            {
                sumSquares += val * val;
            }

            double magnitude = Math.Sqrt(sumSquares);
            
            // Divide each element by magnitude
            if (magnitude > 0)
            {
                for (int i = 0; i < vector.Length; i++)
                {
                    vector[i] = (float)(vector[i] / magnitude);
                }
            }
        }

        /// <summary>
        /// Warms up the model with a dummy inference
        /// First run is always slower, so we do it once at startup
        /// </summary>
        private async Task WarmUpModelAsync()
        {
            try
            {
                _logger.LogInformation("🔥 Warming up ONNX model...");
                var dummyTokens = Enumerable.Repeat(ClsTokenId, MaxSequenceLength).ToArray();
                var inputTensor = CreateInputTensor(dummyTokens);
                var attentionMask = CreateAttentionMask(dummyTokens);
                var tokenTypeIds = CreateTokenTypeIds(dummyTokens);
                
                await Task.Run(() => RunInference(inputTensor, attentionMask, tokenTypeIds));
                
                _logger.LogInformation("✅ Model warm-up completed");
            }
            catch (Exception ex)
            {
                _logger.LogWarning(ex, "⚠️ Model warm-up failed, but continuing");
            }
        }

        /// <summary>
        /// Initialize a simple vocabulary
        /// NOTE: This is simplified! Production would load a 30K+ word vocabulary file
        /// </summary>
        private Dictionary<string, int> InitializeVocabulary()
        {
            return new Dictionary<string, int>
            {
                ["[PAD]"] = PadTokenId,
                ["[CLS]"] = ClsTokenId,
                ["[SEP]"] = SepTokenId,
                // Common words (in production, load from vocab.txt file)
                ["ai"] = 2000,
                ["dashboard"] = 2001,
                ["ticket"] = 2002,
                ["analytics"] = 2003,
                ["support"] = 2004,
                ["idea"] = 2005,
                ["innovation"] = 2006,
                ["platform"] = 2007,
                ["tool"] = 2008,
                ["system"] = 2009,
                ["data"] = 2010,
                ["analysis"] = 2011
            };
        }

        /// <summary>
        /// Cleanup resources when service is disposed
        /// </summary>
        public void Dispose()
        {
            _session?.Dispose();
            _initLock?.Dispose();
        }
    }
}
