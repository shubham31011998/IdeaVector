// Generated with GitHub Copilot - [Tracking ID: Hexure-Copilot]
using FirstMVC.Models.DTOs;
using FirstMVC.Models.MLModels;

namespace FirstMVC.Services.Interfaces
{
    /// <summary>
    /// Service for storing and searching vector embeddings
    /// 
    /// Think of this as a specialized in-memory database:
    /// - Regular DB: Stores text, searches by keywords
    /// - Vector Store: Stores vectors, searches by similarity
    /// 
    /// Purpose: Enable semantic similarity search for duplicate detection
    /// </summary>
    public interface IVectorStoreService
    {
        /// <summary>
        /// Adds or updates an idea's embedding in the vector store
        /// 
        /// What this does:
        /// - If idea is new: Adds it to the store
        /// - If idea exists: Updates its embedding
        /// - Stores in memory (RAM) for fast searching
        /// 
        /// When to call:
        /// - After creating a new idea in database
        /// - After updating an existing idea
        /// - During initial load (indexing existing ideas)
        /// 
        /// Performance:
        /// - Very fast: ~1ms (in-memory operation)
        /// - Thread-safe: Multiple requests can call simultaneously
        /// 
        /// Example:
        /// await store.AddOrUpdateAsync(
        ///     ideaId: 42,
        ///     embedding: [0.23, -0.15, 0.87, ...],
        ///     combinedText: "Title: AI Dashboard. Description: ...",
        ///     categoryName: "Technology"
        /// );
        /// </summary>
        /// <param name="ideaId">ID of the idea (links to Ideas table)</param>
        /// <param name="embedding">384-dimensional embedding vector</param>
        /// <param name="combinedText">Original text that was embedded (for debugging)</param>
        /// <param name="categoryName">Optional: Category name for filtering</param>
        /// <param name="createdBy">Optional: Username of creator</param>
        /// <returns>Task that completes when stored</returns>
        Task AddOrUpdateAsync(int ideaId, float[] embedding, string combinedText, 
            string? categoryName = null, string? createdBy = null);

        /// <summary>
        /// Finds similar ideas based on vector similarity
        /// THIS IS THE CORE DUPLICATE DETECTION METHOD!
        /// 
        /// What this does:
        /// 1. Takes a query embedding (from user's input)
        /// 2. Compares it with ALL stored embeddings
        /// 3. Calculates cosine similarity for each
        /// 4. Filters by threshold (e.g., >0.85)
        /// 5. Sorts by similarity (highest first)
        /// 6. Returns top K results
        /// 
        /// Similarity Score Meaning:
        /// - 1.0 = 100% identical (exact match)
        /// - 0.9-1.0 = Very similar (likely duplicate)
        /// - 0.85-0.9 = Similar (worth reviewing)
        /// - 0.8-0.85 = Somewhat similar
        /// - <0.8 = Different
        /// 
        /// Performance:
        /// - 1,000 ideas: ~50-100ms
        /// - 10,000 ideas: ~100-200ms
        /// - 100,000 ideas: ~500ms-1s
        /// 
        /// Example:
        /// var similar = await store.FindSimilarAsync(
        ///     queryEmbedding: [0.25, -0.13, ...],
        ///     topK: 5,           // Return top 5
        ///     threshold: 0.85,   // At least 85% similar
        ///     excludeIdeaId: 42  // Don't match itself
        /// );
        /// // Returns: List of SimilarityResult objects
        /// </summary>
        /// <param name="queryEmbedding">Embedding vector to search for (384 dimensions)</param>
        /// <param name="topK">Maximum number of results to return (default: 5)</param>
        /// <param name="threshold">Minimum similarity score (0.0 to 1.0, default: 0.85)</param>
        /// <param name="excludeIdeaId">Optional: Exclude this idea from results (useful when editing)</param>
        /// <returns>List of similar ideas, sorted by similarity score (highest first)</returns>
        Task<List<SimilarityResult>> FindSimilarAsync(float[] queryEmbedding, 
            int topK = 5, double threshold = 0.85, int? excludeIdeaId = null);

        /// <summary>
        /// Removes an idea's embedding from the vector store
        /// 
        /// When to call:
        /// - When an idea is deleted from database
        /// - When cleaning up old data
        /// 
        /// What happens:
        /// - Removes from in-memory store
        /// - Future searches won't find this idea
        /// - Original idea still in database (this only affects vector store)
        /// 
        /// Example:
        /// await store.RemoveAsync(42); // Remove idea #42's embedding
        /// </summary>
        /// <param name="ideaId">ID of the idea to remove</param>
        /// <returns>True if removed successfully, false if not found</returns>
        Task<bool> RemoveAsync(int ideaId);

        /// <summary>
        /// Gets the total number of embeddings stored
        /// 
        /// Useful for:
        /// - Monitoring/statistics (how many ideas indexed?)
        /// - Health checks (is store loaded?)
        /// - Admin dashboards
        /// 
        /// Example:
        /// var count = await store.GetCountAsync();
        /// Console.WriteLine($"Indexed {count} ideas");
        /// </summary>
        /// <returns>Count of stored embeddings</returns>
        Task<int> GetCountAsync();

        /// <summary>
        /// Loads all existing ideas from database and generates embeddings
        /// THIS IS A ONE-TIME OPERATION ON STARTUP
        /// 
        /// What this does:
        /// 1. Reads all ideas from SQL Server database
        /// 2. For each idea:
        ///    - Combine title + description
        ///    - Generate embedding (via EmbeddingService)
        ///    - Store in vector store
        /// 3. Returns count of indexed ideas
        /// 
        /// When called:
        /// - Automatically on app startup (if AutoLoadOnStartup = true)
        /// - Manually via admin endpoint (reindex all)
        /// 
        /// Performance:
        /// - 1,000 ideas: ~30-60 seconds
        /// - 10,000 ideas: ~5-10 minutes
        /// - Runs in background (doesn't block app start)
        /// 
        /// Example:
        /// var indexed = await store.LoadExistingIdeasAsync();
        /// Console.WriteLine($"Indexed {indexed} existing ideas");
        /// </summary>
        /// <returns>Number of ideas successfully indexed</returns>
        Task<int> LoadExistingIdeasAsync();

        /// <summary>
        /// Clears all embeddings from the store
        /// 
        /// When to use:
        /// - Before reindexing everything
        /// - Clearing test data
        /// - Memory cleanup
        /// 
        /// ⚠️ WARNING: This removes all embeddings from memory
        /// You'll need to reload to use duplicate detection again
        /// 
        /// Example:
        /// await store.ClearAsync();
        /// // Store is now empty, need to reload ideas
        /// </summary>
        Task ClearAsync();

        /// <summary>
        /// Gets a single embedding by idea ID
        /// 
        /// Useful for:
        /// - Debugging (check if idea is indexed)
        /// - Admin tools (inspect embeddings)
        /// - Verification (did indexing work?)
        /// 
        /// Example:
        /// var embedding = await store.GetByIdAsync(42);
        /// if (embedding != null) {
        ///     Console.WriteLine($"Idea #42 is indexed");
        /// }
        /// </summary>
        /// <param name="ideaId">ID of the idea</param>
        /// <returns>IdeaEmbedding if found, null if not indexed</returns>
        Task<IdeaEmbedding?> GetByIdAsync(int ideaId);
    }
}
