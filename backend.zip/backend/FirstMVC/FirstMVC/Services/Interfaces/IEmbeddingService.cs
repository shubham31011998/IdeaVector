// Generated with GitHub Copilot - [Tracking ID: Hexure-Copilot]
namespace FirstMVC.Services.Interfaces
{
    /// <summary>
    /// Service for generating text embeddings using ONNX model
    /// 
    /// This interface defines WHAT the service does (contract)
    /// The implementation (EmbeddingService.cs) defines HOW it does it
    /// 
    /// Purpose: Convert text into numerical vectors for similarity search
    /// </summary>
    public interface IEmbeddingService
    {
        /// <summary>
        /// Indicates whether the ONNX model is loaded and ready to use
        /// 
        /// Check this before calling other methods!
        /// 
        /// Returns:
        /// - true: Model loaded, ready to generate embeddings
        /// - false: Model not loaded yet, call InitializeAsync() first
        /// 
        /// Example usage:
        /// if (!embeddingService.IsInitialized) {
        ///     await embeddingService.InitializeAsync();
        /// }
        /// </summary>
        bool IsInitialized { get; }

        /// <summary>
        /// Initializes the ONNX model and prepares for inference
        /// 
        /// What this does:
        /// 1. Loads the model.onnx file from disk
        /// 2. Sets up ONNX Runtime for inference
        /// 3. Warms up the model (first run is slowest)
        /// 4. Sets IsInitialized = true
        /// 
        /// When to call:
        /// - Once at application startup (via background service)
        /// - Before first embedding generation
        /// 
        /// Performance:
        /// - Takes 1-3 seconds on first call
        /// - Subsequent calls do nothing (already initialized)
        /// 
        /// Throws:
        /// - FileNotFoundException if model.onnx not found
        /// - InvalidOperationException if ONNX Runtime fails
        /// </summary>
        /// <returns>Task that completes when initialization is done</returns>
        Task InitializeAsync();

        /// <summary>
        /// Generates a 384-dimensional embedding vector from any text
        /// 
        /// What this does:
        /// 1. Takes input text (any string)
        /// 2. Preprocesses it (lowercase, cleanup)
        /// 3. Tokenizes it (converts to numbers)
        /// 4. Runs through ONNX model
        /// 5. Returns 384 floating-point numbers (the embedding)
        /// 
        /// The embedding captures the MEANING of the text:
        /// - Similar meanings → Similar vectors (high cosine similarity)
        /// - Different meanings → Different vectors (low cosine similarity)
        /// 
        /// Performance:
        /// - First call: ~100ms (model warm-up)
        /// - Subsequent calls: ~20-50ms per text
        /// 
        /// Examples:
        /// "AI dashboard for tickets" → [0.23, -0.15, 0.87, ..., 0.42]
        /// "Ticket analytics dashboard" → [0.25, -0.13, 0.85, ..., 0.40]
        /// ↑ These vectors would be very similar (high cosine similarity)
        /// </summary>
        /// <param name="text">Input text to embed (any length, will be truncated if too long)</param>
        /// <returns>384-dimensional float array representing the text meaning</returns>
        /// <exception cref="InvalidOperationException">If service not initialized</exception>
        /// <exception cref="ArgumentException">If text is null or empty</exception>
        Task<float[]> GenerateEmbeddingAsync(string text);

        /// <summary>
        /// Generates an embedding for an idea (convenience method)
        /// Combines title and description intelligently before embedding
        /// 
        /// What this does:
        /// 1. Takes title and description separately
        /// 2. Combines them: "Title: {title}. Description: {description}"
        /// 3. Calls GenerateEmbeddingAsync() on the combined text
        /// 
        /// Why separate method?
        /// - Common use case (most ideas have title + description)
        /// - Consistent formatting across the app
        /// - Easier to use than manually combining
        /// 
        /// Example:
        /// Input:
        ///   title: "AI Dashboard"
        ///   description: "Analytics for support tickets"
        /// 
        /// Internally becomes:
        ///   "Title: AI Dashboard. Description: Analytics for support tickets"
        /// 
        /// Then generates embedding of that combined text
        /// </summary>
        /// <param name="title">Idea title</param>
        /// <param name="description">Idea description</param>
        /// <returns>384-dimensional embedding of combined text</returns>
        Task<float[]> GenerateIdeaEmbeddingAsync(string title, string description);

        /// <summary>
        /// Combines multiple text fields into a single string for embedding
        /// 
        /// What this does:
        /// - Formats text consistently: "Title: {title}. Description: {description}"
        /// - Handles null/empty values gracefully
        /// - Truncates if combined text is too long
        /// 
        /// This is a helper method - doesn't generate embeddings itself
        /// Just formats the text before embedding
        /// 
        /// Why public?
        /// - Sometimes you want to see the combined text without embedding
        /// - Useful for debugging ("What text are we actually embedding?")
        /// - Can be used for logging/testing
        /// 
        /// Example:
        /// Input:
        ///   title: "AI Dashboard"
        ///   description: "Analytics tool"
        /// 
        /// Returns:
        ///   "Title: AI Dashboard. Description: Analytics tool"
        /// </summary>
        /// <param name="title">Title text</param>
        /// <param name="description">Description text</param>
        /// <returns>Combined formatted string ready for embedding</returns>
        string CombineTextFields(string title, string description);
    }
}
