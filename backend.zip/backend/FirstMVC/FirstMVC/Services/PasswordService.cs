namespace FirstMVC.Services
{
    /// <summary>
    /// Service for handling password hashing and verification
    /// </summary>
    public interface IPasswordService
    {
        /// <summary>
        /// Hashes a plain text password
        /// </summary>
        /// <param name="password">Plain text password</param>
        /// <returns>Hashed password</returns>
        string HashPassword(string password);

        /// <summary>
        /// Verifies a password against a hash
        /// </summary>
        /// <param name="password">Plain text password to verify</param>
        /// <param name="hashedPassword">Hashed password from database</param>
        /// <returns>True if password matches, false otherwise</returns>
        bool VerifyPassword(string password, string hashedPassword);
    }

    /// <summary>
    /// Implementation of password service using BCrypt
    /// </summary>
    public class PasswordService : IPasswordService
    {
        /// <summary>
        /// Hashes a password using BCrypt with work factor of 12
        /// </summary>
        /// <param name="password">Plain text password</param>
        /// <returns>BCrypt hashed password</returns>
        public string HashPassword(string password)
        {
            // BCrypt automatically generates a salt and includes it in the hash
            // Work factor of 12 provides good security vs performance balance
            return BCrypt.Net.BCrypt.HashPassword(password, workFactor: 12);
        }

        /// <summary>
        /// Verifies a password against its hash
        /// </summary>
        /// <param name="password">Plain text password to verify</param>
        /// <param name="hashedPassword">BCrypt hashed password from database</param>
        /// <returns>True if password is correct, false otherwise</returns>
        public bool VerifyPassword(string password, string hashedPassword)
        {
            try
            {
                // BCrypt.Verify handles the comparison securely
                return BCrypt.Net.BCrypt.Verify(password, hashedPassword);
            }
            catch
            {
                // If hash is invalid or corrupted, return false
                return false;
            }
        }
    }
}
