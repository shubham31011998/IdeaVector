using System.ComponentModel.DataAnnotations;

namespace FirstMVC.Models.DTOs
{
    public class CreateIdeaDto
    {
        [Required(ErrorMessage = "Title is required")]
        [StringLength(200, ErrorMessage = "Title cannot exceed 200 characters")]
        public string Title { get; set; } = string.Empty;

        [StringLength(2000, ErrorMessage = "Description cannot exceed 2000 characters")]
        public string? Description { get; set; }

        [Required(ErrorMessage = "Category is required")]
        [Range(1, int.MaxValue, ErrorMessage = "Please select a valid category")]
        public int CategoryId { get; set; }

        [Required(ErrorMessage = "SubCategory is required")]
        [Range(1, int.MaxValue, ErrorMessage = "Please select a valid subcategory")]
        public int SubCategoryId { get; set; }

        public bool CustomerShared { get; set; } = false;

        [Required(ErrorMessage = "CreatedBy is required")]
        public int CreatedBy { get; set; }
    }
}