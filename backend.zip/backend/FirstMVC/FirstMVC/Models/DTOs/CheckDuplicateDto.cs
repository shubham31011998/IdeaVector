// Generated with GitHub Copilot - [Tracking ID: Hexure-Copilot]
namespace FirstMVC.Models.DTOs
{
    /// <summary>
    /// Request model for checking duplicate ideas
    /// This is what the frontend sends to the API
    /// </summary>
    public class CheckDuplicateRequestDto
    {
        /// <summary>
        /// Title of the idea to check
        /// Example: "AI Dashboard for Support Tickets"
        /// Required: Yes (user must enter a title)
        /// </summary>
        public string Title { get; set; } = string.Empty;

        /// <summary>
        /// Description of the idea to check
        /// Example: "A tool to analyze support ticket data using AI and machine learning"
        /// Required: Yes (we need description for good matching)
        /// </summary>
        public string Description { get; set; } = string.Empty;

        /// <summary>
        /// Optional: Category ID to filter similar ideas within same category
        /// Example: 5 (Technology category)
        /// If provided, we only show similar ideas in the same category
        /// If null, we search across all categories
        /// </summary>
        public int? CategoryId { get; set; }
    }

    /// <summary>
    /// Response model for duplicate check
    /// This is what the backend sends back to the frontend
    /// </summary>
    public class CheckDuplicateResponseDto
    {
        /// <summary>
        /// Whether similar ideas were found
        /// - true: We found at least one similar idea above threshold
        /// - false: No similar ideas found (safe to proceed)
        /// Example: true
        /// </summary>
        public bool HasSimilar { get; set; }

        /// <summary>
        /// List of similar ideas found
        /// Empty list if no similar ideas
        /// Ordered by similarity score (most similar first)
        /// Example: [ { ideaId: 42, similarityScore: 0.89 }, { ideaId: 108, similarityScore: 0.82 } ]
        /// </summary>
        public List<SimilarityResult> SimilarIdeas { get; set; } = new();

        /// <summary>
        /// Total number of similar ideas found
        /// Convenience property (same as SimilarIdeas.Count)
        /// Example: 2 (found 2 similar ideas)
        /// </summary>
        public int TotalSimilar { get; set; }

        /// <summary>
        /// Suggested action for user
        /// Human-readable recommendation based on findings
        /// Examples:
        /// - "No similar ideas found. Safe to proceed!"
        /// - "Found 2 similar ideas. Please review before submitting."
        /// - "Very similar to Idea #42. Consider updating that idea instead."
        /// Can be null if we don't provide suggestions
        /// </summary>
        public string? Suggestion { get; set; }
    }
}
