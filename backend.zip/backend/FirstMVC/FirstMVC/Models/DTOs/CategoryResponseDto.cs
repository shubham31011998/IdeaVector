namespace FirstMVC.Models.DTOs;

public class CategoryResponseDto
{
    public int CategoryId { get; set; }

    public string CategoryName { get; set; } = string.Empty;

    public int? ParentCategoryId { get; set; }

    public string? ParentCategoryName { get; set; }

    public bool IsActive { get; set; }

    public string? Cat_desc { get; set; }

    public List<CategoryResponseDto>? SubCategories { get; set; }

    public int SubCategoryCount { get; set; }
}