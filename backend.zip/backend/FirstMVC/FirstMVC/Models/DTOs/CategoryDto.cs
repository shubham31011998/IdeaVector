using System.ComponentModel.DataAnnotations;

namespace FirstMVC.Models.DTOs;

public class CategoryDto
{
    [Required(ErrorMessage = "Category name is required")]
    [MaxLength(100, ErrorMessage = "Category name cannot exceed 100 characters")]
    public string CategoryName { get; set; } = string.Empty;

    public int? ParentCategoryId { get; set; }

    public bool IsActive { get; set; } = true;

    [MaxLength(500, ErrorMessage = "Description cannot exceed 500 characters")]
    public string? Cat_desc { get; set; }
}