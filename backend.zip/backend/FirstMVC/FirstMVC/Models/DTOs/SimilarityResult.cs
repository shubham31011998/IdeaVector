// Generated with GitHub Copilot - [Tracking ID: Hexure-Copilot]
namespace FirstMVC.Models.DTOs
{
    /// <summary>
    /// Represents a similar idea found through semantic search
    /// This is what we return to the frontend/API caller
    /// </summary>
    public class SimilarityResult
    {
        /// <summary>
        /// ID of the similar idea
        /// Links back to the Ideas table
        /// Example: 42
        /// </summary>
        public int IdeaId { get; set; }

        /// <summary>
        /// Title of the similar idea
        /// Example: "AI Dashboard for Support Tickets"
        /// </summary>
        public string Title { get; set; } = string.Empty;

        /// <summary>
        /// Description of the similar idea
        /// Example: "A tool to analyze support ticket data using AI"
        /// </summary>
        public string Description { get; set; } = string.Empty;

        /// <summary>
        /// Similarity score (0.0 to 1.0)
        /// - 1.0 = 100% identical
        /// - 0.9+ = Very similar (likely duplicate)
        /// - 0.85-0.9 = Similar (worth checking)
        /// - 0.8-0.85 = Somewhat similar
        /// Example: 0.89 means 89% similar
        /// </summary>
        public double SimilarityScore { get; set; }

        /// <summary>
        /// Human-readable explanation of similarity level
        /// Makes it easier for users to understand
        /// Examples:
        /// - "Almost identical - Very likely duplicate"
        /// - "Very similar - Possibly duplicate"
        /// - "Similar content - Worth reviewing"
        /// </summary>
        public string MatchReason { get; set; } = string.Empty;

        /// <summary>
        /// Optional: Category of the similar idea
        /// Example: "Technology", "Process Improvement"
        /// Helps user understand context
        /// Can be null if idea has no category
        /// </summary>
        public string? CategoryName { get; set; }

        /// <summary>
        /// Optional: When the similar idea was created
        /// Example: 2026-01-15
        /// Helps user see if it's a recent or old idea
        /// Can be null if we don't include this info
        /// </summary>
        public DateTime? CreatedAt { get; set; }
    }
}
