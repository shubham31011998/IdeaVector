namespace FirstMVC.Models.DTOs
{
    public class IdeaDto
    {
        public int IdeaId { get; set; }
        public Guid PublicGuId { get; set; }
        public string Title { get; set; } = string.Empty;
        public string? Description { get; set; }
        public int CategoryId { get; set; }
        public int SubCategoryId { get; set; }
        public bool CustomerShared { get; set; }
        public string Status { get; set; } = string.Empty;
        public int CreatedBy { get; set; }
        public DateTime CreatedDate { get; set; }
    }
}