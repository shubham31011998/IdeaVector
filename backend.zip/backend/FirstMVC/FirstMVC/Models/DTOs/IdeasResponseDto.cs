namespace FirstMVC.Models.DTOs
{
    public class IdeasResponseDto
    {
        public bool Success { get; set; }
        public string Message { get; set; } = string.Empty;
        public List<IdeaDto>? Ideas { get; set; }
        public int TotalCount { get; set; }
    }
}