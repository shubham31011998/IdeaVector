using System.ComponentModel.DataAnnotations;
using System.ComponentModel.DataAnnotations.Schema;

namespace FirstMVC.Models
{
    [Table("SubCategories")]
    public class SubCategory
    {
        [Key]
        public int SubCategoryId { get; set; }

        [Required]
        [MaxLength(100)]
        public string SubCategoryName { get; set; } = string.Empty;

        [MaxLength(500)]
        public string? Description { get; set; }

        // Foreign key to parent category
        [Required]
        public int CategoryId { get; set; }

        public bool IsActive { get; set; } = true;

        // Navigation property - many subcategories belong to one category
        [ForeignKey("CategoryId")]
        public virtual Category? Category { get; set; }

        // Navigation property - one subcategory has many ideas
        public virtual ICollection<Ideas> Ideas { get; set; } = new List<Ideas>();
    }
}