using System.ComponentModel.DataAnnotations;
using System.ComponentModel.DataAnnotations.Schema;

namespace FirstMVC.Models
{
    [Table("IdeaCategoryMaster")]
    public class Category
    {
        [Key]
        public int CategoryId { get; set; }

        [Required]
        [MaxLength(100)]
        public string CategoryName { get; set; } = string.Empty;

        public int? ParentCategoryId { get; set; }

        public bool IsActive { get; set; } = true;

        [MaxLength(500)]
        public string? Cat_desc { get; set; }

        // Navigation property for self-referencing hierarchy
        [ForeignKey("ParentCategoryId")]
        public virtual Category? ParentCategory { get; set; }

        // Navigation property for child categories
        public virtual ICollection<Category> SubCategories { get; set; } = new List<Category>();

        // Navigation property for ideas
        public virtual ICollection<Ideas> Ideas { get; set; } = new List<Ideas>();
    }
}