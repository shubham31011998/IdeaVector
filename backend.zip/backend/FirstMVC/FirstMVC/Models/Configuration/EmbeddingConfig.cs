// Generated with GitHub Copilot - [Tracking ID: Hexure-Copilot]
namespace FirstMVC.Models.Configuration
{
    /// <summary>
    /// Configuration settings for embedding and similarity search system
    /// These values are loaded from appsettings.json
    /// You can change these settings without recompiling code!
    /// </summary>
    public class EmbeddingConfig
    {
        /// <summary>
        /// Path to the ONNX model file
        /// Default: "Models/MLModels/model.onnx"
        /// 
        /// This is where your downloaded all-MiniLM-L6-v2 model lives
        /// Relative path from the application root
        /// 
        /// Example: If your project is at C:\MyApp\
        /// Full path becomes: C:\MyApp\Models\MLModels\model.onnx
        /// </summary>
        public string ModelPath { get; set; } = "Models/MLModels/model.onnx";

        /// <summary>
        /// Dimension of embedding vectors
        /// Default: 384 (for all-MiniLM-L6-v2 model)
        /// 
        /// Different models output different sizes:
        /// - all-MiniLM-L6-v2: 384 dimensions
        /// - BERT-base: 768 dimensions
        /// - GPT embeddings: 1536 dimensions
        /// 
        /// ⚠️ WARNING: Don't change this unless you change the model!
        /// </summary>
        public int ModelDimensions { get; set; } = 384;

        /// <summary>
        /// Minimum similarity threshold for considering ideas as similar/duplicates
        /// Range: 0.0 to 1.0
        /// Default: 0.85 (85% similar)
        /// 
        /// What different values mean:
        /// - 0.95: Very strict (only almost identical ideas)
        /// - 0.85: Balanced (catches duplicates but not too sensitive)
        /// - 0.75: Loose (catches more but may have false positives)
        /// 
        /// Higher = Fewer results, but more accurate
        /// Lower = More results, but may include less relevant ideas
        /// 
        /// 💡 TIP: Start at 0.85 and adjust based on user feedback
        /// </summary>
        public double SimilarityThreshold { get; set; } = 0.85;

        /// <summary>
        /// Maximum number of similar ideas to return
        /// Default: 5
        /// 
        /// Why limit this?
        /// - Better UX (don't overwhelm users with too many results)
        /// - Faster API response (less data to serialize/send)
        /// - Users typically only care about top few matches
        /// 
        /// Recommended: 3-10
        /// </summary>
        public int MaxResults { get; set; } = 5;

        /// <summary>
        /// Whether to automatically load and index existing ideas on application startup
        /// Default: true
        /// 
        /// true = On app start, load all ideas from database and generate embeddings
        ///        Takes time on startup but then searches are instant
        ///        Recommended for production
        /// 
        /// false = Don't load on startup (faster startup, but need manual trigger)
        ///         Useful for development/testing
        /// 
        /// 💡 TIP: Set to false if you have 100K+ ideas (startup would be slow)
        /// </summary>
        public bool AutoLoadOnStartup { get; set; } = true;

        /// <summary>
        /// Maximum text length to process (in characters)
        /// Default: 5000 characters
        /// 
        /// Why limit this?
        /// - Models have token limits
        /// - Very long text takes longer to process
        /// - Most ideas are much shorter anyway
        /// 
        /// If text exceeds this, it will be truncated (cut off)
        /// 5000 chars ≈ 1000 words ≈ plenty for most ideas!
        /// </summary>
        public int MaxTextLength { get; set; } = 5000;
    }
}
