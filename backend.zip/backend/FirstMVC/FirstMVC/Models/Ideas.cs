﻿using System.ComponentModel.DataAnnotations;
using System.ComponentModel.DataAnnotations.Schema;

namespace FirstMVC.Models
{
    [Table("Ideas")]
    public class Ideas
    {
        [Key]
        public int IdeaId { get; set; }

        // Public GUID for URL routing (non-guessable)
        [Required]
        public Guid PublicGuId { get; set; } = Guid.NewGuid();

        [Required]
        [MaxLength(200)]
        public string Title { get; set; } = string.Empty;

        public string? Description { get; set; }

        [Required]
        public int CategoryId { get; set; }

        [Required]
        public int SubCategoryId { get; set; }

        public bool CustomerShared { get; set; }

        [Required]
        [MaxLength(50)]
        public string Status { get; set; } = string.Empty;

        public int CreatedBy { get; set; }

        public DateTime CreatedDate { get; set; } = DateTime.UtcNow;

        // Navigation properties
        [ForeignKey("CategoryId")]
        public virtual Category? Category { get; set; }

        //[ForeignKey("SubCategoryId")]
        //public virtual Category? SubCategory { get; set; }

        //[ForeignKey("CreatedBy")]
        //public virtual User? CreatedByUser { get; set; }
    }
}