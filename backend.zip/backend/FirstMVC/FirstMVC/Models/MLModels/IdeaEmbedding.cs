// Generated with GitHub Copilot - [Tracking ID: Hexure-Copilot]
namespace FirstMVC.Models.MLModels
{
    /// <summary>
    /// Represents an idea's vector embedding for semantic similarity search
    /// This is stored in memory (RAM) for fast searching
    /// </summary>
    public class IdeaEmbedding
    {
        /// <summary>
        /// ID of the idea from the database
        /// Links back to your Ideas table in SQL Server
        /// </summary>
        public int IdeaId { get; set; }

        /// <summary>
        /// The 384-dimensional embedding vector generated from idea text
        /// This is an array of 384 floating-point numbers
        /// Example: [0.23, -0.15, 0.87, ... (381 more numbers)]
        /// </summary>
        public float[] Embedding { get; set; } = Array.Empty<float>();

        /// <summary>
        /// Combined text (title + description) that was used to generate embedding
        /// We store this so we can debug or re-generate if needed
        /// Example: "Title: AI Dashboard. Description: Analytics for support tickets"
        /// </summary>
        public string CombinedText { get; set; } = string.Empty;

        /// <summary>
        /// When this embedding was generated
        /// Useful for tracking freshness and debugging
        /// </summary>
        public DateTime CreatedAt { get; set; }

        /// <summary>
        /// Optional: Category name for filtering similar ideas
        /// Example: "Technology", "Process Improvement"
        /// Can be null if idea doesn't have a category
        /// </summary>
        public string? CategoryName { get; set; }

        /// <summary>
        /// Optional: User who created the idea
        /// Stored as string (could be username or ID)
        /// Can be null if we don't track this
        /// </summary>
        public string? CreatedBy { get; set; }
    }
}
