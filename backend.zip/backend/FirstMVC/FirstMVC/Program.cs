﻿using Microsoft.EntityFrameworkCore;
using FirstMVC.Data;
using FirstMVC.Services;
using FirstMVC.Services.Interfaces;
using FirstMVC.Models.Configuration;

namespace FirstMVC
{
    public class Program
    {
        public static void Main(string[] args)
        {
            var builder = WebApplication.CreateBuilder(args);

            // ✅ Add this — registers the database
            builder.Services.AddDbContext<ApplicationDbContext>(options =>
                options.UseSqlServer(builder.Configuration.GetConnectionString("DefaultConnection")));

            // Add CORS policy
            builder.Services.AddCors(options =>
            {
                options.AddPolicy("AllowFrontend", policy =>
                {
                    policy.WithOrigins("http://localhost:5173") // Your frontend URL
                          .AllowAnyHeader()
                          .AllowAnyMethod();
                });
                options.AddPolicy("AllowOrigin", policy =>
                {
                    policy.WithOrigins("http://localhost:3000")
                           .AllowAnyHeader()
                           .AllowAnyMethod();
                });
            });

            // Register Password Service for dependency injection
            builder.Services.AddScoped<IPasswordService, PasswordService>();

            // ═══════════════════════════════════════════════════════════════
            // ✅ EMBEDDING & DUPLICATE DETECTION SERVICES
            // ═══════════════════════════════════════════════════════════════
            
            // Register Embedding Configuration (reads from appsettings.json)
            builder.Services.Configure<EmbeddingConfig>(
                builder.Configuration.GetSection("EmbeddingConfig"));

            // Register Embedding Services as Singleton
            // Why Singleton? 
            // - ONNX model loaded once and reused (expensive to create)
            // - Vector store holds data in memory (must persist across requests)
            // - Thread-safe (multiple requests can use simultaneously)
            builder.Services.AddSingleton<IEmbeddingService, EmbeddingService>();
            builder.Services.AddSingleton<IVectorStoreService, VectorStoreService>();

            // Register Background Service for initialization
            // This runs automatically when app starts
            builder.Services.AddHostedService<EmbeddingInitializationService>();
            
            // ═══════════════════════════════════════════════════════════════

            // Add services to the container.
            builder.Services.AddControllersWithViews();

            // Enable CORS middleware (must be before UseAuthorization)
            var app = builder.Build();

            app.UseCors("AllowFrontend"); // or "AllowOrigin"

            // Configure the HTTP request pipeline.
            if (!app.Environment.IsDevelopment())
            {
                app.UseExceptionHandler("/Home/Error");
                // The default HSTS value is 30 days. You may want to change this for production scenarios, see https://aka.ms/aspnetcore-hsts.
                app.UseHsts();
                app.UseHttpsRedirection(); // Only use HTTPS redirection in production
            }

            app.UseStaticFiles();

            app.UseRouting();


            app.UseAuthorization();
            app.MapControllers();
            app.MapControllerRoute(
                name: "default",
                pattern: "{controller=Home}/{action=Index}/{id?}");

            app.Run();
        }
    }
}