﻿using FirstMVC.Data;
using FirstMVC.Models.DTOs; // Ensure this using is present
using FirstMVC.Services;
using Microsoft.AspNetCore.Mvc;
using Microsoft.EntityFrameworkCore;
using System.Security.Cryptography;

namespace FirstMVC.Controllers.Api;

[Route("api/[controller]")]
[ApiController]
public class AuthController : ControllerBase
{
    private readonly ApplicationDbContext _context;
    private readonly ILogger<AuthController> _logger;
    private readonly IPasswordService _passwordService;

    public AuthController(
        ApplicationDbContext context, 
        ILogger<AuthController> logger,
        IPasswordService passwordService)
    {
        _context = context;
        _logger = logger;
        _passwordService = passwordService;
    }

    /// <summary>
    /// User login endpoint
    /// </summary>
    /// <param name="loginRequest">Login credentials</param>
    /// <returns>Login response with user information</returns>
    [HttpPost("login")]
    [ProducesResponseType(StatusCodes.Status200OK)]
    [ProducesResponseType(StatusCodes.Status400BadRequest)]
    [ProducesResponseType(StatusCodes.Status401Unauthorized)]
    public async Task<ActionResult<LoginResponseDto>> Login([FromBody] LoginRequestDto loginRequest)
    {
        try
        {
            if (!ModelState.IsValid)
            {
                return BadRequest(new LoginResponseDto
                {
                    Success = false,
                    Message = "Invalid request data"
                });
            }

            // Find user by username or email
            var user = await _context.Users
                .FirstOrDefaultAsync(u => (u.Username == loginRequest.UsernameOrEmail));


            if (user == null)
            {
                return Unauthorized(new LoginResponseDto
                {
                    Success = false,
                    Message = "Invalid username or password"
                });
            }

            // Verify password using BCrypt hashing
            if (!_passwordService.VerifyPassword(loginRequest.Password, user.PasswordHash))
            {
                return Unauthorized(new LoginResponseDto
                {
                    Success = false,
                    Message = "Invalid username or password"
                });
            }

            // Successful login
            return Ok(new LoginResponseDto
            {
                Success = true,
                Message = "Login successful",
                User = new UserDto
                {
                    UserId = user.UserId,
                    Username = user.Username,
                    //Email = user.Email,
                    //IsActive = user.IsActive
                }
            });
        }
        catch (Exception ex)
        {
            _logger.LogError(ex, "Error during login attempt for user: {UsernameOrEmail}", loginRequest.UsernameOrEmail);
            return StatusCode(500, new LoginResponseDto
            {
                Success = false,
                Message = "An error occurred during login"
            });
        }
    }

    /// <summary>
    /// User registration endpoint
    /// </summary>
    /// <param name="registerRequest">Registration details</param>
    /// <returns>Registration response with user information</returns>
    [HttpPost("register")]
    [ProducesResponseType(StatusCodes.Status200OK)]
    [ProducesResponseType(StatusCodes.Status400BadRequest)]
    public async Task<ActionResult<RegisterResponseDto>> Register([FromBody] RegisterRequestDto registerRequest)
    {
        try
        {
            if (!ModelState.IsValid)
            {
                return BadRequest(new RegisterResponseDto
                {
                    Success = false,
                    Message = "Invalid request data"
                });
            }

            // Check if username already exists
            var existingUser = await _context.Users
                .FirstOrDefaultAsync(u => u.Username == registerRequest.Username);

            if (existingUser != null)
            {
                return BadRequest(new RegisterResponseDto
                {
                    Success = false,
                    Message = "Username already exists"
                });
            }

            // Hash the password before storing
            var hashedPassword = _passwordService.HashPassword(registerRequest.Password);
            // ✅ This works:
            int randomId;
            do
            {
                randomId = RandomNumberGenerator.GetInt32(0, 1000);
            } while (await _context.Users.AnyAsync(u => u.UserId == randomId));

            // Create new user
            var newUser = new Models.User
            {
                UserId = randomId,
                Username = registerRequest.Username,
                PasswordHash = hashedPassword
            };

            _context.Users.Add(newUser);
            await _context.SaveChangesAsync();

            _logger.LogInformation("New user registered successfully: {Username}", newUser.Username);

            // Return success response
            return Ok(new RegisterResponseDto
            {
                Success = true,
                Message = "Registration successful",
                User = new UserDto
                {
                    UserId = newUser.UserId,
                    Username = newUser.Username
                }
            });
        }
        catch (Exception ex)
        {
            _logger.LogError(ex, "Error during registration for username: {Username}", registerRequest.Username);
            return StatusCode(500, new RegisterResponseDto
            {
                Success = false,
                Message = "An error occurred during registration"
            });
        }
    }
}