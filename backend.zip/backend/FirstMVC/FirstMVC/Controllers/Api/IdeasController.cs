﻿using Microsoft.AspNetCore.Mvc;
using Microsoft.EntityFrameworkCore;
using FirstMVC.Data;
using FirstMVC.Models;
using FirstMVC.Models.DTOs;

namespace FirstMVC.Controllers.Api;

[Route("api/[controller]")]
[ApiController]
public class IdeasController : ControllerBase
{
    private readonly ApplicationDbContext _context;
    private readonly ILogger<IdeasController> _logger;

    public IdeasController(ApplicationDbContext context, ILogger<IdeasController> logger)
    {
        _context = context;
        _logger = logger;
    }

    /// <summary>
    /// Get all ideas
    /// </summary>
    [HttpGet]
    [ProducesResponseType(StatusCodes.Status200OK)]
    [ProducesResponseType(StatusCodes.Status500InternalServerError)]
    public async Task<ActionResult<IdeasResponseDto>> GetIdeas()
    {
        try
        {
            var ideas = await _context.Ideas
                .OrderByDescending(i => i.CreatedDate)
                .Select(i => new IdeaDto
                {
                    IdeaId = i.IdeaId,
                    PublicGuId = i.PublicGuId,
                    Title = i.Title,
                    Description = i.Description,
                    CategoryId = i.CategoryId,
                    SubCategoryId = i.SubCategoryId,
                    Status = i.Status,
                    CreatedBy = i.CreatedBy,
                    CreatedDate = i.CreatedDate
                })
                .ToListAsync();

            return Ok(new IdeasResponseDto
            {
                Success = true,
                Message = "Ideas retrieved successfully",
                Ideas = ideas,
                TotalCount = ideas.Count
            });
        }
        catch (Exception ex)
        {
            _logger.LogError(ex, "Error retrieving ideas");
            return StatusCode(500, new IdeasResponseDto
            {
                Success = false,
                Message = "An error occurred while retrieving ideas"
            });
        }
    }

    /// <summary>
    /// Get idea by ID
    /// </summary>
    [HttpGet("{id}")]
    [ProducesResponseType(StatusCodes.Status200OK)]
    [ProducesResponseType(StatusCodes.Status404NotFound)]
    public async Task<ActionResult<ApiResponse<IdeaDto>>> GetIdeaById(int id)
    {
        try
        {
            var idea = await _context.Ideas
                .Where(i => i.IdeaId == id)
                .Select(i => new IdeaDto {
                    IdeaId = i.IdeaId,
                    PublicGuId = i.PublicGuId,
                    Title = i.Title,
                    Description = i.Description,
                    CategoryId = i.CategoryId,
                    SubCategoryId = i.SubCategoryId,
                    Status = i.Status,
                    CreatedBy = i.CreatedBy,
                    CreatedDate = i.CreatedDate
                })
                .FirstOrDefaultAsync();

            if (idea == null)
                return NotFound(new ApiResponse<IdeaDto> { Success = false, Message = "Idea not found" });

            return Ok(new ApiResponse<IdeaDto> { Success = true, Data = idea });
        }
        catch (Exception ex)
        {
            _logger.LogError(ex, "Error retrieving ideas");
            return StatusCode(500, new IdeasResponseDto
            {
                Success = false,
                Message = "An error occurred while retrieving ideas"
            });
        }
    }

    /// <summary>
    /// Get idea by Public GUID (secure, non-guessable ID)
    /// </summary>
    [HttpGet("public/{PublicGuId:guid}")]
    [ProducesResponseType(StatusCodes.Status200OK)]
    [ProducesResponseType(StatusCodes.Status404NotFound)]
    public async Task<ActionResult<ApiResponse<IdeaDto>>> GetIdeaByPublicGuId(Guid PublicGuId)
    {
        try
        {
            var idea = await _context.Ideas
                .Where(i => i.PublicGuId == PublicGuId)
                .Select(i => new IdeaDto
                {
                    IdeaId = i.IdeaId,
                    PublicGuId = i.PublicGuId,
                    Title = i.Title,
                    Description = i.Description,
                    CategoryId = i.CategoryId,
                    SubCategoryId = i.SubCategoryId,
                    CustomerShared = i.CustomerShared,
                    Status = i.Status,
                    CreatedBy = i.CreatedBy,
                    CreatedDate = i.CreatedDate
                })
                .FirstOrDefaultAsync();

            if (idea == null)
            {
                _logger.LogWarning("Idea with PublicGuId {PublicGuId} not found", PublicGuId);
                return NotFound(new ApiResponse<IdeaDto> 
                { 
                    Success = false, 
                    Message = "Idea not found" 
                });
            }

            return Ok(new ApiResponse<IdeaDto> 
            { 
                Success = true, 
                Data = idea,
                Message = "Idea retrieved successfully"
            });
        }
        catch (Exception ex)
        {
            _logger.LogError(ex, "Error retrieving idea by PublicGuId {PublicGuId}", PublicGuId);
            return StatusCode(500, new ApiResponse<IdeaDto>
            {
                Success = false,
                Message = "An error occurred while retrieving the idea"
            });
        }
    }

    /// <summary>
    /// Create a new idea
    /// </summary>
    [HttpPost]
    [ProducesResponseType(StatusCodes.Status201Created)]
    [ProducesResponseType(StatusCodes.Status400BadRequest)]
    [ProducesResponseType(StatusCodes.Status500InternalServerError)]
    public async Task<ActionResult<ApiResponse<IdeaDto>>> CreateIdea([FromBody] CreateIdeaDto createIdeaDto)
    {
        try
        {
            // Validate model
            if (!ModelState.IsValid)
            {
                var errors = ModelState.Values
                    .SelectMany(v => v.Errors)
                    .Select(e => e.ErrorMessage)
                    .ToList();

                return BadRequest(new ApiResponse<IdeaDto>
                {
                    Success = false,
                    Message = "Validation failed",
                    Errors = errors
                });
            }

            // Optional: Validate that CategoryId and SubCategoryId exist
            // var categoryExists = await _context.Categories.AnyAsync(c => c.CategoryId == createIdeaDto.CategoryId);
            // if (!categoryExists)
            // {
            //     return BadRequest(new ApiResponse<IdeaDto>
            //     {
            //         Success = false,
            //         Message = "Invalid category",
            //         Errors = new List<string> { "The specified category does not exist" }
            //     });
            // }

            // Create new idea entity
            var newIdea = new Ideas
            {
                PublicGuId = Guid.NewGuid(), // Generate unique GUID for public URL
                Title = createIdeaDto.Title,
                Description = createIdeaDto.Description,
                CategoryId = createIdeaDto.CategoryId,
                SubCategoryId = createIdeaDto.SubCategoryId,
                CustomerShared = createIdeaDto.CustomerShared,
                Status = "New", // Default status
                CreatedBy = createIdeaDto.CreatedBy,
                CreatedDate = DateTime.UtcNow
            };

            // Add to database
            _context.Ideas.Add(newIdea);
            await _context.SaveChangesAsync();

            // Map to DTO for response
            var ideaDto = new IdeaDto
            {
                IdeaId = newIdea.IdeaId,
                PublicGuId = newIdea.PublicGuId,
                Title = newIdea.Title,
                Description = newIdea.Description,
                CategoryId = newIdea.CategoryId,
                SubCategoryId = newIdea.SubCategoryId,
                CustomerShared = newIdea.CustomerShared,
                Status = newIdea.Status,
                CreatedBy = newIdea.CreatedBy,
                CreatedDate = newIdea.CreatedDate
            };

            _logger.LogInformation("Idea created successfully with ID: {IdeaId}", newIdea.IdeaId);

            return CreatedAtAction(
                nameof(GetIdeaById),
                new { id = newIdea.IdeaId },
                new ApiResponse<IdeaDto>
                {
                    Success = true,
                    Message = "Idea created successfully",
                    Data = ideaDto
                });
        }
        catch (DbUpdateException ex)
        {
            _logger.LogError(ex, "Database error while creating idea");
            return StatusCode(500, new ApiResponse<IdeaDto>
            {
                Success = false,
                Message = "A database error occurred while creating the idea",
                Errors = new List<string> { "Please check that all required fields are valid" }
            });
        }
        catch (Exception ex)
        {
            _logger.LogError(ex, "Error creating idea");
            return StatusCode(500, new ApiResponse<IdeaDto>
            {
                Success = false,
                Message = "An unexpected error occurred while creating the idea",
                Errors = new List<string> { ex.Message }
            });
        }
    }

    /// <summary>
    /// Delete an idea by ID
    /// </summary>
    [HttpDelete("{id}")]
    [ProducesResponseType(StatusCodes.Status200OK)]
    [ProducesResponseType(StatusCodes.Status404NotFound)]
    [ProducesResponseType(StatusCodes.Status500InternalServerError)]
    public async Task<ActionResult<ApiResponse<object>>> DeleteIdea(int id)
    {
        try
        {
            _logger.LogInformation("Attempting to delete idea with ID: {IdeaId}", id);

            // Find the idea
            var idea = await _context.Ideas.FindAsync(id);

            if (idea == null)
            {
                _logger.LogWarning("Idea with ID {IdeaId} not found", id);
                return NotFound(new ApiResponse<object>
                {
                    Success = false,
                    Message = $"Idea with ID {id} not found"
                });
            }

            // Remove from database
            _context.Ideas.Remove(idea);
            await _context.SaveChangesAsync();

            _logger.LogInformation("Idea with ID {IdeaId} deleted successfully", id);

            return Ok(new ApiResponse<object>
            {
                Success = true,
                Message = "Idea deleted successfully"
            });
        }
        catch (DbUpdateException ex)
        {
            _logger.LogError(ex, "Database error while deleting idea {IdeaId}", id);
            return StatusCode(500, new ApiResponse<object>
            {
                Success = false,
                Message = "A database error occurred while deleting the idea",
                Errors = new List<string> { "The idea may be referenced by other records" }
            });
        }
        catch (Exception ex)
        {
            _logger.LogError(ex, "Error deleting idea {IdeaId}", id);
            return StatusCode(500, new ApiResponse<object>
            {
                Success = false,
                Message = "An unexpected error occurred while deleting the idea",
                Errors = new List<string> { ex.Message }
            });
        }
    }
}