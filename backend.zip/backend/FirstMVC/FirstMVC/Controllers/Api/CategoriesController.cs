using FirstMVC.Data;
using FirstMVC.Models;
using FirstMVC.Models.DTOs;
using Microsoft.AspNetCore.Mvc;
using Microsoft.EntityFrameworkCore;

namespace FirstMVC.Controllers.Api
{
    [Route("api/[controller]")]
    [ApiController]
    public class CategoriesController : ControllerBase
    {
        private readonly ApplicationDbContext _context;
        private readonly ILogger<CategoriesController> _logger;

        public CategoriesController(ApplicationDbContext context, ILogger<CategoriesController> logger)
        {
            _context = context;
            _logger = logger;
        }

        /// <summary>
        /// Get all categories
        /// </summary>
        /// <returns>List of all categories</returns>
        [HttpGet]
        [ProducesResponseType(StatusCodes.Status200OK)]
        [ProducesResponseType(StatusCodes.Status500InternalServerError)]
        public async Task<ActionResult<IEnumerable<CategoryResponseDto>>> GetAllCategories()
        {
            try
            {
                var categories = await _context.Categories
                    .Where(c => c.IsActive)
                    .OrderBy(c => c.CategoryName)
                    .Select(c => new CategoryResponseDto
                    {
                        CategoryId = c.CategoryId,
                        CategoryName = c.CategoryName,
                        ParentCategoryId = c.ParentCategoryId,
                        IsActive = c.IsActive,
                        Cat_desc = c.Cat_desc,
                        SubCategoryCount = _context.Categories.Count(sc => sc.ParentCategoryId == c.CategoryId && sc.IsActive)
                    })
                    .ToListAsync();

                _logger.LogInformation("Retrieved {Count} categories", categories.Count);
                
                return Ok(categories);
            }
            catch (Exception ex)
            {
                _logger.LogError(ex, "Error retrieving categories");
                return StatusCode(500, new { message = "An error occurred while retrieving categories" });
            }
        }

        /// <summary>
        /// Get all parent categories (categories without a parent)
        /// </summary>
        /// <returns>List of parent categories</returns>
        [HttpGet("parents")]
        [ProducesResponseType(StatusCodes.Status200OK)]
        [ProducesResponseType(StatusCodes.Status500InternalServerError)]
        public async Task<ActionResult<IEnumerable<CategoryResponseDto>>> GetParentCategories()
        {
            try
            {
                var categories = await _context.Categories
                    .Where(c => c.IsActive && c.ParentCategoryId == null)
                    .OrderBy(c => c.CategoryName)
                    .Select(c => new CategoryResponseDto
                    {
                        CategoryId = c.CategoryId,
                        CategoryName = c.CategoryName,
                        ParentCategoryId = c.ParentCategoryId,
                        IsActive = c.IsActive,
                        Cat_desc = c.Cat_desc,
                        SubCategoryCount = _context.Categories.Count(sc => sc.ParentCategoryId == c.CategoryId && sc.IsActive)
                    })
                    .ToListAsync();

                _logger.LogInformation("Retrieved {Count} parent categories", categories.Count);
                
                return Ok(categories);
            }
            catch (Exception ex)
            {
                _logger.LogError(ex, "Error retrieving parent categories");
                return StatusCode(500, new { message = "An error occurred while retrieving parent categories" });
            }
        }

        /// <summary>
        /// Get categories with their subcategories in a hierarchical structure
        /// Optimized for React frontend with nested children
        /// </summary>
        /// <returns>List of parent categories with nested subcategories</returns>
        [HttpGet("nested")]
        [ProducesResponseType(StatusCodes.Status200OK)]
        [ProducesResponseType(StatusCodes.Status500InternalServerError)]
        public async Task<ActionResult<IEnumerable<CategoryResponseDto>>> GetCategoriesWithHierarchy()
        {
            try
            {
                // Fetch all active categories in one query
                var allCategories = await _context.Categories
                    .Where(c => c.IsActive)
                    .OrderBy(c => c.CategoryName)
                    .ToListAsync();

                // Build hierarchical structure
                var categoryLookup = allCategories.ToDictionary(c => c.CategoryId);
                var rootCategories = new List<CategoryResponseDto>();

                foreach (var category in allCategories.Where(c => c.ParentCategoryId == null))
                {
                    rootCategories.Add(BuildCategoryHierarchy(category, allCategories));
                }

                _logger.LogInformation("Retrieved {Count} parent categories with {Total} total categories",
                    rootCategories.Count, allCategories.Count);

                return Ok(rootCategories);
            }
            catch (Exception ex)
            {
                _logger.LogError(ex, "Error retrieving categories with hierarchy");
                return StatusCode(500, new { message = "An error occurred while retrieving categories" });
            }
        }

        // Private helper method to recursively build category hierarchy
        private CategoryResponseDto BuildCategoryHierarchy(Category category, List<Category> allCategories)
        {
            var children = allCategories
                .Where(c => c.ParentCategoryId == category.CategoryId)
                .Select(c => BuildCategoryHierarchy(c, allCategories))
                .ToList();

            return new CategoryResponseDto
            {
                CategoryId = category.CategoryId,
                CategoryName = category.CategoryName,
                ParentCategoryId = category.ParentCategoryId,
                IsActive = category.IsActive,
                Cat_desc = category.Cat_desc,
                SubCategories = children.Any() ? children : null,
                SubCategoryCount = children.Count
            };
        }
    }
}