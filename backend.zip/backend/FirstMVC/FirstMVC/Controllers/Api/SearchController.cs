// Generated with GitHub Copilot - [Tracking ID: Hexure-Copilot]
using Microsoft.AspNetCore.Mvc;
using FirstMVC.Services.Interfaces;
using FirstMVC.Models.DTOs;

namespace FirstMVC.Controllers.Api
{
    [ApiController]
    [Route("api/[controller]")]
    public class SearchController : ControllerBase
    {
        private readonly IEmbeddingService _embeddingService;
        private readonly IVectorStoreService _vectorStoreService;
        private readonly ILogger<SearchController> _logger;

        public SearchController(
            IEmbeddingService embeddingService,
            IVectorStoreService vectorStoreService,
            ILogger<SearchController> logger)
        {
            _embeddingService = embeddingService;
            _vectorStoreService = vectorStoreService;
            _logger = logger;
        }

        /// <summary>
        /// Check if an idea is similar to existing ideas before creating it
        /// </summary>
        /// <param name="request">The idea to check (title + description)</param>
        /// <returns>List of similar ideas if any duplicates found</returns>
        [HttpPost("check-duplicate")]
        [ProducesResponseType(typeof(CheckDuplicateResponseDto), StatusCodes.Status200OK)]
        [ProducesResponseType(StatusCodes.Status400BadRequest)]
        [ProducesResponseType(StatusCodes.Status503ServiceUnavailable)]
        public async Task<ActionResult<CheckDuplicateResponseDto>> CheckDuplicate(
            [FromBody] CheckDuplicateRequestDto request)
        {
            try
            {
                _logger.LogInformation("🔍 Checking for duplicates: Title='{Title}'", request.Title);

                // Validate input
                if (string.IsNullOrWhiteSpace(request.Title))
                {
                    return BadRequest(new CheckDuplicateResponseDto
                    {
                        HasSimilar = false,
                        SimilarIdeas = new List<SimilarityResult>(),
                        TotalSimilar = 0,
                        Suggestion = "Title is required"
                    });
                }

                // Check if embedding service is ready
                if (!_embeddingService.IsInitialized)
                {
                    _logger.LogWarning("⚠️ Embedding service not initialized yet");
                    return StatusCode(
                        StatusCodes.Status503ServiceUnavailable,
                        new CheckDuplicateResponseDto
                        {
                            HasSimilar = false,
                            SimilarIdeas = new List<SimilarityResult>(),
                            TotalSimilar = 0,
                            Suggestion = "Duplicate detection service is initializing. Please try again in a moment."
                        });
                }

                // Generate embedding for the new idea
                var embedding = await _embeddingService.GenerateIdeaEmbeddingAsync(
                    request.Title,
                    request.Description ?? string.Empty);

                if (embedding == null || embedding.Length == 0)
                {
                    _logger.LogError("❌ Failed to generate embedding");
                    return StatusCode(
                        StatusCodes.Status500InternalServerError,
                        new CheckDuplicateResponseDto
                        {
                            HasSimilar = false,
                            SimilarIdeas = new List<SimilarityResult>(),
                            TotalSimilar = 0,
                            Suggestion = "Failed to analyze idea. Please try again."
                        });
                }

                // Search for similar ideas
                var similarIdeas = await _vectorStoreService.FindSimilarAsync(
                    queryEmbedding: embedding,
                    topK: 5,
                    threshold: 0.80, // 80% similarity threshold
                    excludeIdeaId: null);

                _logger.LogInformation(
                    "📊 Found {Count} similar ideas (threshold: 80%)",
                    similarIdeas.Count);

                // Build response
                var response = new CheckDuplicateResponseDto
                {
                    HasSimilar = similarIdeas.Any(),
                    SimilarIdeas = similarIdeas,
                    TotalSimilar = similarIdeas.Count,
                    Suggestion = GenerateSuggestion(similarIdeas)
                };

                return Ok(response);
            }
            catch (Exception ex)
            {
                _logger.LogError(ex, "❌ Error checking for duplicates");
                return StatusCode(
                    StatusCodes.Status500InternalServerError,
                    new CheckDuplicateResponseDto
                    {
                        HasSimilar = false,
                        SimilarIdeas = new List<SimilarityResult>(),
                        TotalSimilar = 0,
                        Suggestion = "An error occurred while checking for duplicates."
                    });
            }
        }

        /// <summary>
        /// Generate user-friendly suggestion based on similarity results
        /// </summary>
        private string GenerateSuggestion(List<SimilarityResult> similarIdeas)
        {
            if (!similarIdeas.Any())
            {
                return "✅ No similar ideas found. This appears to be unique!";
            }

            var highestScore = similarIdeas.First().SimilarityScore;

            if (highestScore >= 0.90)
            {
                return "⚠️ Very similar ideas already exist. Please review them before proceeding.";
            }
            else if (highestScore >= 0.85)
            {
                return "ℹ️ Similar ideas found. Consider reviewing or combining with existing ideas.";
            }
            else
            {
                return "💡 Some related ideas exist. Your idea has unique aspects worth exploring.";
            }
        }

        /// <summary>
        /// Health check endpoint to verify the embedding system is ready
        /// </summary>
        [HttpGet("health")]
        [ProducesResponseType(StatusCodes.Status200OK)]
        [ProducesResponseType(StatusCodes.Status503ServiceUnavailable)]
        public ActionResult<object> Health()
        {
            var isReady = _embeddingService.IsInitialized;
            var ideaCount = _vectorStoreService.GetCountAsync().Result;

            var status = new
            {
                Status = isReady ? "Ready" : "Initializing",
                EmbeddingServiceReady = isReady,
                IdeasIndexed = ideaCount,
                Timestamp = DateTime.UtcNow
            };

            if (isReady)
            {
                return Ok(status);
            }
            else
            {
                return StatusCode(StatusCodes.Status503ServiceUnavailable, status);
            }
        }
    }
}
